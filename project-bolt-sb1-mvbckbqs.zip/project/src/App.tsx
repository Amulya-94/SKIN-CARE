import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Target, 
  Users, 
  MessageSquare, 
  Palette, 
  Instagram, 
  Calendar, 
  BarChart3,
  Download,
  Share2,
  Search,
  Bookmark,
  Crown,
  Mic,
  Video,
  Gamepad2,
  Coins,
  Menu,
  X,
  ChevronRight,
  CheckCircle,
  TrendingUp,
  Heart,
  Shield,
  Zap,
  Brain,
  Leaf,
  User,
  LogIn
} from 'lucide-react';
import { exportToPDF } from './utils/pdfExport';
import VoiceAssistant from './components/VoiceAssistant';
import SearchModal from './components/SearchModal';
import ShareModal from './components/ShareModal';
import BookmarkManager from './components/BookmarkManager';
import PaywallModal from './components/PaywallModal';
import PremiumFeatures from './components/PremiumFeatures';
import TavusVideoAgent from './components/TavusVideoAgent';
import RedditGames from './components/RedditGames';
import BlockchainNFT from './components/BlockchainNFT';
import AIInsights from './components/AIInsights';
import EthicalImpactTracker from './components/EthicalImpactTracker';
import ViralPredictionEngine from './components/ViralPredictionEngine';
import AuthModal from './components/AuthModal';
import UserMenu from './components/UserMenu';
import ProfileView from './components/ProfileView';
import { supabase } from './lib/supabase';

function App() {
  const [activeSection, setActiveSection] = useState('objectives');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [isBookmarkOpen, setIsBookmarkOpen] = useState(false);
  const [isPaywallOpen, setIsPaywallOpen] = useState(false);
  const [isTavusOpen, setIsTavusOpen] = useState(false);
  const [isRedditGamesOpen, setIsRedditGamesOpen] = useState(false);
  const [isBlockchainOpen, setIsBlockchainOpen] = useState(false);
  const [isAIInsightsOpen, setIsAIInsightsOpen] = useState(false);
  const [isEthicalTrackerOpen, setIsEthicalTrackerOpen] = useState(false);
  const [isViralEngineOpen, setIsViralEngineOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isPremiumUser, setIsPremiumUser] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check initial auth state
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      setIsLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleVoiceCommand = (command: string) => {
    const lowerCommand = command.toLowerCase();
    
    if (lowerCommand.includes('objective')) {
      setActiveSection('objectives');
    } else if (lowerCommand.includes('audience')) {
      setActiveSection('audience');
    } else if (lowerCommand.includes('message')) {
      setActiveSection('messages');
    } else if (lowerCommand.includes('content')) {
      setActiveSection('content');
    } else if (lowerCommand.includes('platform')) {
      setActiveSection('platforms');
    } else if (lowerCommand.includes('criteria') || lowerCommand.includes('selection')) {
      setActiveSection('criteria');
    } else if (lowerCommand.includes('timeline')) {
      setActiveSection('timeline');
    } else if (lowerCommand.includes('metric') || lowerCommand.includes('kpi')) {
      setActiveSection('metrics');
    } else if (lowerCommand.includes('export') || lowerCommand.includes('download')) {
      exportToPDF();
    } else if (lowerCommand.includes('share')) {
      setIsShareOpen(true);
    } else if (lowerCommand.includes('search')) {
      setIsSearchOpen(true);
    } else if (lowerCommand.includes('insights') || lowerCommand.includes('ai')) {
      setIsAIInsightsOpen(true);
    } else if (lowerCommand.includes('impact') || lowerCommand.includes('ethical')) {
      setIsEthicalTrackerOpen(true);
    } else if (lowerCommand.includes('viral') || lowerCommand.includes('prediction')) {
      setIsViralEngineOpen(true);
    }
  };

  const handleNavigate = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handlePurchaseSuccess = () => {
    setIsPremiumUser(true);
  };

  const handleAuthSuccess = (authUser: any) => {
    setUser(authUser);
    setIsAuthOpen(false);
  };

  const handleSignOut = () => {
    setUser(null);
  };

  const sections = [
    { id: 'objectives', title: 'Campaign Objectives', icon: Target },
    { id: 'audience', title: 'Target Audience', icon: Users },
    { id: 'messages', title: 'Key Brand Messages', icon: MessageSquare },
    { id: 'content', title: 'Content Themes', icon: Palette },
    { id: 'platforms', title: 'Social Platforms', icon: Instagram },
    { id: 'criteria', title: 'Selection Criteria', icon: CheckCircle },
    { id: 'timeline', title: 'Campaign Timeline', icon: Calendar },
    { id: 'metrics', title: 'Success Metrics', icon: BarChart3 }
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-emerald-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-emerald-200 border-t-emerald-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-600">Loading CampaignCraft Pro...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-emerald-50">
      {/* Built with Bolt.new Badge */}
      <div className="fixed bottom-4 left-4 z-40">
        <a
          href="https://bolt.new"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 px-3 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors shadow-lg text-sm font-medium"
        >
          <Zap className="h-4 w-4 text-yellow-400" />
          <span>Built with Bolt.new</span>
        </a>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-xl">
                <Sparkles className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-800">CampaignCraft Pro</h1>
                <p className="text-xs text-slate-500">Ethical Marketing Platform</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-6">
              <button
                onClick={() => setIsSearchOpen(true)}
                className="flex items-center gap-2 px-3 py-2 text-slate-600 hover:text-emerald-600 transition-colors"
              >
                <Search className="h-4 w-4" />
                <span>Search</span>
              </button>
              <button
                onClick={() => setIsBookmarkOpen(true)}
                className="flex items-center gap-2 px-3 py-2 text-slate-600 hover:text-emerald-600 transition-colors"
              >
                <Bookmark className="h-4 w-4" />
                <span>Bookmarks</span>
              </button>
              <button
                onClick={() => setIsShareOpen(true)}
                className="flex items-center gap-2 px-3 py-2 text-slate-600 hover:text-emerald-600 transition-colors"
              >
                <Share2 className="h-4 w-4" />
                <span>Share</span>
              </button>
              <button
                onClick={exportToPDF}
                className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
              >
                <Download className="h-4 w-4" />
                <span>Export PDF</span>
              </button>
              
              {/* Auth Section */}
              {user ? (
                <UserMenu user={user} onSignOut={handleSignOut} />
              ) : (
                <button
                  onClick={() => setIsAuthOpen(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <LogIn className="h-4 w-4" />
                  <span>Sign In</span>
                </button>
              )}
            </nav>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-slate-600 hover:text-emerald-600 transition-colors"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>

          {/* Mobile Menu */}
          {isMobileMenuOpen && (
            <div className="lg:hidden py-4 border-t border-slate-200">
              <div className="flex flex-col gap-2">
                <button
                  onClick={() => { setIsSearchOpen(true); setIsMobileMenuOpen(false); }}
                  className="flex items-center gap-2 px-3 py-2 text-slate-600 hover:text-emerald-600 transition-colors"
                >
                  <Search className="h-4 w-4" />
                  <span>Search</span>
                </button>
                <button
                  onClick={() => { setIsBookmarkOpen(true); setIsMobileMenuOpen(false); }}
                  className="flex items-center gap-2 px-3 py-2 text-slate-600 hover:text-emerald-600 transition-colors"
                >
                  <Bookmark className="h-4 w-4" />
                  <span>Bookmarks</span>
                </button>
                <button
                  onClick={() => { setIsShareOpen(true); setIsMobileMenuOpen(false); }}
                  className="flex items-center gap-2 px-3 py-2 text-slate-600 hover:text-emerald-600 transition-colors"
                >
                  <Share2 className="h-4 w-4" />
                  <span>Share</span>
                </button>
                <button
                  onClick={() => { exportToPDF(); setIsMobileMenuOpen(false); }}
                  className="flex items-center gap-2 px-3 py-2 text-slate-600 hover:text-emerald-600 transition-colors"
                >
                  <Download className="h-4 w-4" />
                  <span>Export PDF</span>
                </button>
                
                {user ? (
                  <button
                    onClick={() => { setIsProfileOpen(true); setIsMobileMenuOpen(false); }}
                    className="flex items-center gap-2 px-3 py-2 text-slate-600 hover:text-emerald-600 transition-colors"
                  >
                    <User className="h-4 w-4" />
                    <span>Profile</span>
                  </button>
                ) : (
                  <button
                    onClick={() => { setIsAuthOpen(true); setIsMobileMenuOpen(false); }}
                    className="flex items-center gap-2 px-3 py-2 text-blue-600 hover:text-blue-700 transition-colors"
                  >
                    <LogIn className="h-4 w-4" />
                    <span>Sign In</span>
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="hidden lg:block w-80 bg-white border-r border-slate-200 h-[calc(100vh-4rem)] sticky top-16 overflow-y-auto">
          <div className="p-6">
            {/* AI-Powered Features */}
            <div className="mb-8">
              <h3 className="text-sm font-semibold text-slate-800 mb-4">AI-Powered Features</h3>
              <div className="space-y-2">
                <button
                  onClick={() => setIsAIInsightsOpen(true)}
                  className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-purple-50 transition-colors group"
                >
                  <Brain className="h-5 w-5 text-purple-600" />
                  <div className="flex-1 text-left">
                    <p className="font-medium text-slate-800">AI Campaign Insights</p>
                    <p className="text-xs text-slate-500">Market intelligence & optimization</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-slate-400 group-hover:text-purple-600" />
                </button>
                
                <button
                  onClick={() => setIsViralEngineOpen(true)}
                  className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-orange-50 transition-colors group"
                >
                  <Zap className="h-5 w-5 text-orange-600" />
                  <div className="flex-1 text-left">
                    <p className="font-medium text-slate-800">Viral Prediction Engine</p>
                    <p className="text-xs text-slate-500">AI virality analysis</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-slate-400 group-hover:text-orange-600" />
                </button>
                
                <button
                  onClick={() => setIsEthicalTrackerOpen(true)}
                  className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-emerald-50 transition-colors group"
                >
                  <Leaf className="h-5 w-5 text-emerald-600" />
                  <div className="flex-1 text-left">
                    <p className="font-medium text-slate-800">Ethical Impact Tracker</p>
                    <p className="text-xs text-slate-500">Measure positive impact</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-slate-400 group-hover:text-emerald-600" />
                </button>
              </div>
            </div>

            {/* Challenge Features */}
            <div className="mb-8">
              <h3 className="text-sm font-semibold text-slate-800 mb-4">Challenge Features</h3>
              <div className="space-y-2">
                <button
                  onClick={() => setIsTavusOpen(true)}
                  className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-purple-50 transition-colors group"
                >
                  <Video className="h-5 w-5 text-purple-600" />
                  <div className="flex-1 text-left">
                    <p className="font-medium text-slate-800">AI Video Agent</p>
                    <p className="text-xs text-slate-500">Tavus Integration</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-slate-400 group-hover:text-purple-600" />
                </button>
                
                <button
                  onClick={() => setIsRedditGamesOpen(true)}
                  className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-orange-50 transition-colors group"
                >
                  <Gamepad2 className="h-5 w-5 text-orange-600" />
                  <div className="flex-1 text-left">
                    <p className="font-medium text-slate-800">Reddit Games</p>
                    <p className="text-xs text-slate-500">Silly Challenges</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-slate-400 group-hover:text-orange-600" />
                </button>
                
                <button
                  onClick={() => setIsBlockchainOpen(true)}
                  className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-blue-50 transition-colors group"
                >
                  <Coins className="h-5 w-5 text-blue-600" />
                  <div className="flex-1 text-left">
                    <p className="font-medium text-slate-800">Blockchain NFTs</p>
                    <p className="text-xs text-slate-500">Algorand Integration</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-slate-400 group-hover:text-blue-600" />
                </button>
                
                <button
                  onClick={() => setIsPaywallOpen(true)}
                  className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-purple-50 transition-colors group"
                >
                  <Crown className="h-5 w-5 text-purple-600" />
                  <div className="flex-1 text-left">
                    <p className="font-medium text-slate-800">Premium Features</p>
                    <p className="text-xs text-slate-500">RevenueCat Integration</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-slate-400 group-hover:text-purple-600" />
                </button>
              </div>
            </div>

            {/* Navigation */}
            <div>
              <h3 className="text-sm font-semibold text-slate-800 mb-4">Campaign Sections</h3>
              <nav className="space-y-1">
                {sections.map((section) => {
                  const Icon = section.icon;
                  return (
                    <button
                      key={section.id}
                      onClick={() => handleNavigate(section.id)}
                      className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors ${
                        activeSection === section.id
                          ? 'bg-emerald-100 text-emerald-700'
                          : 'text-slate-600 hover:bg-slate-50 hover:text-emerald-600'
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                      <span className="font-medium">{section.title}</span>
                    </button>
                  );
                })}
              </nav>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6 lg:p-8">
          <div className="max-w-4xl mx-auto">
            {/* Hero Section */}
            <div className="mb-12 text-center">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-100 text-emerald-700 rounded-full text-sm font-medium mb-6">
                <Heart className="h-4 w-4" />
                <span>Cruelty-Free Campaign</span>
              </div>
              <h1 className="text-4xl lg:text-5xl font-bold text-slate-800 mb-4">
                Ethical Skincare
                <span className="block text-emerald-600">Influencer Campaign</span>
              </h1>
              <p className="text-xl text-slate-600 max-w-2xl mx-auto">
                Comprehensive marketing strategy for promoting cruelty-free skincare products through authentic influencer partnerships
              </p>
            </div>

            {/* Campaign Objectives */}
            <section id="objectives" className="mb-16">
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2 bg-emerald-100 rounded-lg">
                    <Target className="h-6 w-6 text-emerald-600" />
                  </div>
                  <h2 className="text-2xl font-bold text-slate-800">Campaign Objectives</h2>
                </div>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <TrendingUp className="h-5 w-5 text-emerald-600 mt-1" />
                      <div>
                        <h3 className="font-semibold text-slate-800">Brand Awareness</h3>
                        <p className="text-slate-600">Increase cruelty-free brand awareness by 35% within 6 months through authentic storytelling</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <Sparkles className="h-5 w-5 text-emerald-600 mt-1" />
                      <div>
                        <h3 className="font-semibold text-slate-800">Product Launch</h3>
                        <p className="text-slate-600">Generate buzz around new product launches with emphasis on ingredient transparency</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <Users className="h-5 w-5 text-emerald-600 mt-1" />
                      <div>
                        <h3 className="font-semibold text-slate-800">Community Building</h3>
                        <p className="text-slate-600">Build an engaged community of ethically-minded consumers</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <BarChart3 className="h-5 w-5 text-emerald-600 mt-1" />
                      <div>
                        <h3 className="font-semibold text-slate-800">Sales Conversion</h3>
                        <p className="text-slate-600">Drive 25% increase in online sales through authentic product demonstrations</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Target Audience */}
            <section id="audience" className="mb-16">
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Users className="h-6 w-6 text-blue-600" />
                  </div>
                  <h2 className="text-2xl font-bold text-slate-800">Target Audience</h2>
                </div>
                
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="bg-slate-50 rounded-xl p-6">
                    <h3 className="font-semibold text-slate-800 mb-3">Demographics</h3>
                    <ul className="space-y-2 text-slate-600">
                      <li>• Age: 22-45 years</li>
                      <li>• Gender: 75% Female, 25% Male</li>
                      <li>• Location: Urban & Suburban</li>
                      <li>• Income: $40K-$100K+</li>
                      <li>• Education: College-educated</li>
                    </ul>
                  </div>
                  
                  <div className="bg-slate-50 rounded-xl p-6">
                    <h3 className="font-semibold text-slate-800 mb-3">Psychographics</h3>
                    <ul className="space-y-2 text-slate-600">
                      <li>• Values animal welfare</li>
                      <li>• Environmental sustainability</li>
                      <li>• Ethical consumption</li>
                      <li>• Transparency in brands</li>
                      <li>• Quality over quantity</li>
                    </ul>
                  </div>
                  
                  <div className="bg-slate-50 rounded-xl p-6">
                    <h3 className="font-semibold text-slate-800 mb-3">Interests</h3>
                    <ul className="space-y-2 text-slate-600">
                      <li>• Clean beauty products</li>
                      <li>• Wellness & self-care</li>
                      <li>• Sustainable living</li>
                      <li>• Research-driven decisions</li>
                      <li>• Social responsibility</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>

            {/* Key Brand Messages */}
            <section id="messages" className="mb-16">
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2 bg-purple-100 rounded-lg">
                    <MessageSquare className="h-6 w-6 text-purple-600" />
                  </div>
                  <h2 className="text-2xl font-bold text-slate-800">Key Brand Messages</h2>
                </div>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-6">
                    <div className="border-l-4 border-emerald-500 pl-6">
                      <h3 className="font-semibold text-slate-800 mb-2">Cruelty-Free Commitment</h3>
                      <p className="text-slate-600">Beauty without compromise - our products are never tested on animals and are certified cruelty-free by leading organizations.</p>
                    </div>
                    
                    <div className="border-l-4 border-blue-500 pl-6">
                      <h3 className="font-semibold text-slate-800 mb-2">Transparency & Trust</h3>
                      <p className="text-slate-600">Complete ingredient transparency with honest communication about our sourcing, manufacturing, and brand values.</p>
                    </div>
                  </div>
                  
                  <div className="space-y-6">
                    <div className="border-l-4 border-purple-500 pl-6">
                      <h3 className="font-semibold text-slate-800 mb-2">Ethical Sourcing</h3>
                      <p className="text-slate-600">Responsibly sourced ingredients that respect both people and planet, supporting sustainable communities.</p>
                    </div>
                    
                    <div className="border-l-4 border-orange-500 pl-6">
                      <h3 className="font-semibold text-slate-800 mb-2">Authentic Results</h3>
                      <p className="text-slate-600">Real results from real ingredients - effective skincare that aligns with your values and delivers visible improvements.</p>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Content Themes */}
            <section id="content" className="mb-16">
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2 bg-orange-100 rounded-lg">
                    <Palette className="h-6 w-6 text-orange-600" />
                  </div>
                  <h2 className="text-2xl font-bold text-slate-800">Content Themes & Formats</h2>
                </div>
                
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="bg-gradient-to-br from-emerald-50 to-blue-50 rounded-xl p-6">
                    <h3 className="font-semibold text-slate-800 mb-4">Educational Content</h3>
                    <ul className="space-y-2 text-slate-600">
                      <li>• Ingredient spotlights</li>
                      <li>• Skincare education</li>
                      <li>• Ethics & values content</li>
                      <li>• How-to tutorials</li>
                      <li>• Myth-busting posts</li>
                    </ul>
                  </div>
                  
                  <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6">
                    <h3 className="font-semibold text-slate-800 mb-4">Authentic Reviews</h3>
                    <ul className="space-y-2 text-slate-600">
                      <li>• Honest product reviews</li>
                      <li>• Before & after transformations</li>
                      <li>• Comparison content</li>
                      <li>• Long-term usage updates</li>
                      <li>• Skin journey documentation</li>
                    </ul>
                  </div>
                  
                  <div className="bg-gradient-to-br from-orange-50 to-yellow-50 rounded-xl p-6">
                    <h3 className="font-semibold text-slate-800 mb-4">Lifestyle Integration</h3>
                    <ul className="space-y-2 text-slate-600">
                      <li>• Daily routines</li>
                      <li>• Behind-the-scenes content</li>
                      <li>• User-generated content</li>
                      <li>• Seasonal adaptations</li>
                      <li>• Travel-friendly tips</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>

            {/* Social Media Platforms */}
            <section id="platforms" className="mb-16">
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2 bg-pink-100 rounded-lg">
                    <Instagram className="h-6 w-6 text-pink-600" />
                  </div>
                  <h2 className="text-2xl font-bold text-slate-800">Social Media Platforms</h2>
                </div>
                
                <div className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="bg-gradient-to-br from-pink-50 to-purple-50 rounded-xl p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <Instagram className="h-6 w-6 text-pink-600" />
                        <h3 className="text-lg font-semibold text-slate-800">Instagram (Primary)</h3>
                      </div>
                      <p className="text-slate-600 mb-4">Visual storytelling through posts, stories, and reels</p>
                      <ul className="space-y-1 text-sm text-slate-600">
                        <li>• Product photography & tutorials</li>
                        <li>• Behind-the-scenes content</li>
                        <li>• User-generated content campaigns</li>
                        <li>• Target audience: 25-40 years</li>
                      </ul>
                    </div>
                    
                    <div className="bg-gradient-to-br from-slate-50 to-gray-50 rounded-xl p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <Video className="h-6 w-6 text-slate-600" />
                        <h3 className="text-lg font-semibold text-slate-800">TikTok (Primary)</h3>
                      </div>
                      <p className="text-slate-600 mb-4">Short-form educational content and trends</p>
                      <ul className="space-y-1 text-sm text-slate-600">
                        <li>• Quick tutorials & tips</li>
                        <li>• Trending challenges</li>
                        <li>• Authentic demonstrations</li>
                        <li>• Target audience: 18-35 years</li>
                      </ul>
                    </div>
                  </div>
                  
                  <div className="bg-gradient-to-br from-red-50 to-orange-50 rounded-xl p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <Video className="h-6 w-6 text-red-600" />
                      <h3 className="text-lg font-semibold text-slate-800">YouTube (Secondary)</h3>
                    </div>
                    <p className="text-slate-600 mb-4">Long-form educational content and comprehensive guides</p>
                    <div className="grid md:grid-cols-3 gap-4">
                      <div>
                        <h4 className="font-medium text-slate-800 mb-2">Content Types</h4>
                        <ul className="space-y-1 text-sm text-slate-600">
                          <li>• Detailed product reviews</li>
                          <li>• Skincare routines</li>
                          <li>• Educational series</li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-medium text-slate-800 mb-2">Engagement</h4>
                        <ul className="space-y-1 text-sm text-slate-600">
                          <li>• Q&A sessions</li>
                          <li>• Live demonstrations</li>
                          <li>• Community polls</li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-medium text-slate-800 mb-2">Metrics</h4>
                        <ul className="space-y-1 text-sm text-slate-600">
                          <li>• Watch time optimization</li>
                          <li>• Subscriber growth</li>
                          <li>• Comment engagement</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Influencer Selection Criteria */}
            <section id="criteria" className="mb-16">
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <CheckCircle className="h-6 w-6 text-green-600" />
                  </div>
                  <h2 className="text-2xl font-bold text-slate-800">Influencer Selection Criteria</h2>
                </div>
                
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <h3 className="text-lg font-semibold text-slate-800 mb-4">Quantitative Metrics</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                        <span className="font-medium text-slate-800">Follower Count</span>
                        <span className="text-emerald-600 font-semibold">10K - 500K</span>
                      </div>
                      <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                        <span className="font-medium text-slate-800">Engagement Rate</span>
                        <span className="text-emerald-600 font-semibold">≥ 3.5%</span>
                      </div>
                      <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                        <span className="font-medium text-slate-800">Content Quality</span>
                        <span className="text-emerald-600 font-semibold">High Standards</span>
                      </div>
                      <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                        <span className="font-medium text-slate-800">Posting Frequency</span>
                        <span className="text-emerald-600 font-semibold">3-5x/week</span>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold text-slate-800 mb-4">Qualitative Factors</h3>
                    <div className="space-y-4">
                      <div className="flex items-start gap-3 p-4 bg-emerald-50 rounded-lg">
                        <Shield className="h-5 w-5 text-emerald-600 mt-1" />
                        <div>
                          <h4 className="font-medium text-slate-800">Values Alignment</h4>
                          <p className="text-sm text-slate-600">Genuine commitment to cruelty-free and ethical practices</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start gap-3 p-4 bg-blue-50 rounded-lg">
                        <MessageSquare className="h-5 w-5 text-blue-600 mt-1" />
                        <div>
                          <h4 className="font-medium text-slate-800">Authentic Voice</h4>
                          <p className="text-sm text-slate-600">Transparent communication and honest product reviews</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start gap-3 p-4 bg-purple-50 rounded-lg">
                        <Users className="h-5 w-5 text-purple-600 mt-1" />
                        <div>
                          <h4 className="font-medium text-slate-800">Audience Match</h4>
                          <p className="text-sm text-slate-600">Demographics align with target market</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start gap-3 p-4 bg-orange-50 rounded-lg">
                        <CheckCircle className="h-5 w-5 text-orange-600 mt-1" />
                        <div>
                          <h4 className="font-medium text-slate-800">Professional Standards</h4>
                          <p className="text-sm text-slate-600">Reliable delivery and professional communication</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Campaign Timeline */}
            <section id="timeline" className="mb-16">
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2 bg-indigo-100 rounded-lg">
                    <Calendar className="h-6 w-6 text-indigo-600" />
                  </div>
                  <h2 className="text-2xl font-bold text-slate-800">Campaign Timeline</h2>
                </div>
                
                <div className="space-y-8">
                  <div className="relative">
                    <div className="absolute left-4 top-8 bottom-0 w-0.5 bg-slate-200"></div>
                    
                    <div className="relative flex items-start gap-6">
                      <div className="flex-shrink-0 w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center">
                        <span className="text-sm font-semibold text-emerald-600">1</span>
                      </div>
                      <div className="flex-1">
                        <div className="bg-emerald-50 rounded-xl p-6">
                          <h3 className="text-lg font-semibold text-slate-800 mb-2">Pre-Launch Phase</h3>
                          <p className="text-slate-600 mb-4">Weeks 1-2: Foundation and preparation</p>
                          <div className="grid md:grid-cols-2 gap-4">
                            <ul className="space-y-2 text-sm text-slate-600">
                              <li>• Influencer outreach & vetting</li>
                              <li>• Contract negotiations</li>
                              <li>• Content brief creation</li>
                            </ul>
                            <ul className="space-y-2 text-sm text-slate-600">
                              <li>• Product sampling</li>
                              <li>• Campaign asset preparation</li>
                              <li>• Timeline coordination</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="relative">
                    <div className="relative flex items-start gap-6">
                      <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-sm font-semibold text-blue-600">2</span>
                      </div>
                      <div className="flex-1">
                        <div className="bg-blue-50 rounded-xl p-6">
                          <h3 className="text-lg font-semibold text-slate-800 mb-2">Active Campaign</h3>
                          <p className="text-slate-600 mb-4">Weeks 3-8: Content creation and publication</p>
                          <div className="grid md:grid-cols-2 gap-4">
                            <ul className="space-y-2 text-sm text-slate-600">
                              <li>• Content creation & approval</li>
                              <li>• Scheduled content publication</li>
                              <li>• Real-time engagement monitoring</li>
                            </ul>
                            <ul className="space-y-2 text-sm text-slate-600">
                              <li>• Community management</li>
                              <li>• Performance optimization</li>
                              <li>• Weekly progress reviews</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="relative">
                    <div className="relative flex items-start gap-6">
                      <div className="flex-shrink-0 w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                        <span className="text-sm font-semibold text-purple-600">3</span>
                      </div>
                      <div className="flex-1">
                        <div className="bg-purple-50 rounded-xl p-6">
                          <h3 className="text-lg font-semibold text-slate-800 mb-2">Post-Campaign</h3>
                          <p className="text-slate-600 mb-4">Weeks 9-10: Analysis and optimization</p>
                          <div className="grid md:grid-cols-2 gap-4">
                            <ul className="space-y-2 text-sm text-slate-600">
                              <li>• Comprehensive performance analysis</li>
                              <li>• ROI calculation & reporting</li>
                              <li>• Influencer feedback collection</li>
                            </ul>
                            <ul className="space-y-2 text-sm text-slate-600">
                              <li>• Relationship nurturing</li>
                              <li>• Future collaboration planning</li>
                              <li>• Campaign optimization insights</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Success Metrics */}
            <section id="metrics" className="mb-16">
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2 bg-cyan-100 rounded-lg">
                    <BarChart3 className="h-6 w-6 text-cyan-600" />
                  </div>
                  <h2 className="text-2xl font-bold text-slate-800">Success Metrics & KPIs</h2>
                </div>
                
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="bg-gradient-to-br from-emerald-50 to-green-50 rounded-xl p-6">
                    <h3 className="text-lg font-semibold text-slate-800 mb-4">Awareness Metrics</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-600">Total Reach</span>
                        <span className="font-semibold text-emerald-600">2M+</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-600">Impressions</span>
                        <span className="font-semibold text-emerald-600">8M+</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-600">Brand Mentions</span>
                        <span className="font-semibold text-emerald-600">+150%</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-600">Share of Voice</span>
                        <span className="font-semibold text-emerald-600">+25%</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl p-6">
                    <h3 className="text-lg font-semibold text-slate-800 mb-4">Engagement Metrics</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-600">Engagement Rate</span>
                        <span className="font-semibold text-blue-600">≥ 4.5%</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-600">Comments Quality</span>
                        <span className="font-semibold text-blue-600">High</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-600">Share Rate</span>
                        <span className="font-semibold text-blue-600">≥ 2%</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-600">Save Rate</span>
                        <span className="font-semibold text-blue-600">≥ 3%</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6">
                    <h3 className="text-lg font-semibold text-slate-800 mb-4">Conversion Metrics</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-600">Click-through Rate</span>
                        <span className="font-semibold text-purple-600">≥ 2.5%</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-600">Conversion Rate</span>
                        <span className="font-semibold text-purple-600">≥ 3%</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-600">Revenue Attribution</span>
                        <span className="font-semibold text-purple-600">25%+</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-600">Customer Acquisition</span>
                        <span className="font-semibold text-purple-600">$45 CAC</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-8 p-6 bg-slate-50 rounded-xl">
                  <h3 className="text-lg font-semibold text-slate-800 mb-4">Qualitative Success Indicators</h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <ul className="space-y-2 text-slate-600">
                      <li>• Positive sentiment analysis (&gt;80% positive mentions)</li>
                      <li>• Increased brand trust and credibility</li>
                      <li>• Strengthened influencer relationships</li>
                    </ul>
                    <ul className="space-y-2 text-slate-600">
                      <li>• Enhanced brand reputation in ethical beauty space</li>
                      <li>• Improved customer loyalty and retention</li>
                      <li>• Successful community building and engagement</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>

            {/* Premium Features CTA */}
            {!isPremiumUser && !user && (
              <section className="mb-16">
                <PremiumFeatures onUpgrade={() => setIsPaywallOpen(true)} />
              </section>
            )}

            {/* Footer */}
            <footer className="text-center py-8 border-t border-slate-200">
              <div className="flex items-center justify-center gap-2 mb-4">
                <div className="p-2 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-xl">
                  <Sparkles className="h-5 w-5 text-white" />
                </div>
                <span className="text-lg font-semibold text-slate-800">CampaignCraft Pro</span>
              </div>
              <p className="text-slate-600 mb-2">Professional Influencer Marketing Platform</p>
              <p className="text-sm text-slate-500">
                Empowering ethical brands to create authentic, impactful campaigns
              </p>
            </footer>
          </div>
        </main>
      </div>

      {/* Voice Assistant */}
      <VoiceAssistant onVoiceCommand={handleVoiceCommand} />

      {/* Modals */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onNavigate={handleNavigate}
      />
      
      <ShareModal
        isOpen={isShareOpen}
        onClose={() => setIsShareOpen(false)}
      />
      
      <BookmarkManager
        isOpen={isBookmarkOpen}
        onClose={() => setIsBookmarkOpen(false)}
      />
      
      <PaywallModal
        isOpen={isPaywallOpen}
        onClose={() => setIsPaywallOpen(false)}
        onPurchaseSuccess={handlePurchaseSuccess}
      />
      
      <TavusVideoAgent
        isOpen={isTavusOpen}
        onClose={() => setIsTavusOpen(false)}
      />
      
      <RedditGames
        isOpen={isRedditGamesOpen}
        onClose={() => setIsRedditGamesOpen(false)}
      />
      
      <BlockchainNFT
        isOpen={isBlockchainOpen}
        onClose={() => setIsBlockchainOpen(false)}
      />
      
      <AIInsights
        isOpen={isAIInsightsOpen}
        onClose={() => setIsAIInsightsOpen(false)}
      />
      
      <EthicalImpactTracker
        isOpen={isEthicalTrackerOpen}
        onClose={() => setIsEthicalTrackerOpen(false)}
      />
      
      <ViralPredictionEngine
        isOpen={isViralEngineOpen}
        onClose={() => setIsViralEngineOpen(false)}
      />

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onAuthSuccess={handleAuthSuccess}
      />

      <ProfileView
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        user={user}
      />
    </div>
  );
}

export default App;