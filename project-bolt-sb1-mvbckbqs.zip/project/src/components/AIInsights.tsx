import React, { useState, useEffect } from 'react';
import { Brain, TrendingUp, Target, Users, Lightbulb, X, Sparkles } from 'lucide-react';

interface AIInsightsProps {
  isOpen: boolean;
  onClose: () => void;
}

const AIInsights: React.FC<AIInsightsProps> = ({ isOpen, onClose }) => {
  const [insights, setInsights] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      generateInsights();
    }
  }, [isOpen]);

  const generateInsights = async () => {
    setIsLoading(true);
    
    // Simulate AI analysis delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const aiInsights = [
      {
        type: 'trend',
        title: 'Emerging Trend Alert',
        description: 'Clean beauty hashtags are trending 340% higher this month. Consider incorporating #CleanBeautyRevolution in your campaign.',
        impact: 'High',
        confidence: 94,
        icon: TrendingUp,
        color: 'emerald'
      },
      {
        type: 'audience',
        title: 'Audience Optimization',
        description: 'Your target demographic shows 67% higher engagement with video content between 6-8 PM EST. Adjust posting schedule accordingly.',
        impact: 'Medium',
        confidence: 87,
        icon: Users,
        color: 'blue'
      },
      {
        type: 'strategy',
        title: 'Content Strategy Insight',
        description: 'Micro-influencers (10K-50K followers) in the cruelty-free space have 4.2x higher conversion rates than macro-influencers.',
        impact: 'High',
        confidence: 91,
        icon: Target,
        color: 'purple'
      },
      {
        type: 'innovation',
        title: 'Innovation Opportunity',
        description: 'AR try-on filters for cruelty-free products are underutilized. Only 12% of competitors use this technology.',
        impact: 'High',
        confidence: 89,
        icon: Lightbulb,
        color: 'orange'
      }
    ];
    
    setInsights(aiInsights);
    setIsLoading(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b bg-gradient-to-r from-purple-50 to-blue-50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Brain className="h-5 w-5 text-purple-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-800">AI Campaign Insights</h3>
              <p className="text-sm text-slate-600">Real-time market intelligence and optimization recommendations</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-slate-400" />
          </button>
        </div>

        {isLoading ? (
          <div className="p-12 text-center">
            <div className="w-12 h-12 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-slate-600 mb-2">Analyzing market data...</p>
            <p className="text-sm text-slate-500">Processing 50M+ data points from social platforms</p>
          </div>
        ) : (
          <div className="p-6">
            {/* AI Analysis Summary */}
            <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl p-6 mb-6">
              <div className="flex items-center gap-2 mb-3">
                <Sparkles className="h-5 w-5 text-purple-600" />
                <h4 className="text-lg font-semibold text-slate-800">Campaign Intelligence Summary</h4>
              </div>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-emerald-600 mb-1">+23%</div>
                  <div className="text-sm text-slate-600">Projected Performance Increase</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600 mb-1">4.7/5</div>
                  <div className="text-sm text-slate-600">Campaign Optimization Score</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600 mb-1">89%</div>
                  <div className="text-sm text-slate-600">Market Alignment Confidence</div>
                </div>
              </div>
            </div>

            {/* Insights Grid */}
            <div className="space-y-4">
              {insights.map((insight, index) => {
                const Icon = insight.icon;
                const colorClasses = {
                  emerald: 'bg-emerald-50 border-emerald-200 text-emerald-700',
                  blue: 'bg-blue-50 border-blue-200 text-blue-700',
                  purple: 'bg-purple-50 border-purple-200 text-purple-700',
                  orange: 'bg-orange-50 border-orange-200 text-orange-700'
                };

                return (
                  <div key={index} className="border border-slate-200 rounded-xl p-6 hover:border-purple-200 transition-colors">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${colorClasses[insight.color as keyof typeof colorClasses]}`}>
                          <Icon className="h-5 w-5" />
                        </div>
                        <div>
                          <h5 className="font-semibold text-slate-800">{insight.title}</h5>
                          <div className="flex items-center gap-2 mt-1">
                            <span className={`px-2 py-1 text-xs rounded-full ${
                              insight.impact === 'High' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                            }`}>
                              {insight.impact} Impact
                            </span>
                            <span className="text-xs text-slate-500">
                              {insight.confidence}% confidence
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <p className="text-slate-600 mb-4">{insight.description}</p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-full bg-slate-200 rounded-full h-2 w-24">
                          <div 
                            className="bg-purple-600 h-2 rounded-full transition-all duration-1000"
                            style={{ width: `${insight.confidence}%` }}
                          ></div>
                        </div>
                        <span className="text-xs text-slate-500">{insight.confidence}%</span>
                      </div>
                      
                      <button className="px-3 py-1 bg-purple-100 hover:bg-purple-200 text-purple-700 rounded-lg text-sm transition-colors">
                        Apply Insight
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Action Items */}
            <div className="mt-6 p-4 bg-slate-50 rounded-lg">
              <h4 className="font-medium text-slate-800 mb-2">Recommended Actions</h4>
              <ul className="text-sm text-slate-600 space-y-1">
                <li>• Update influencer selection criteria to prioritize micro-influencers</li>
                <li>• Incorporate trending hashtags into content calendar</li>
                <li>• Adjust posting schedule for optimal engagement windows</li>
                <li>• Explore AR filter partnerships for product trials</li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AIInsights;