import React, { useState, useEffect } from 'react';
import { Coins, X, Download, Share2, Award, Zap } from 'lucide-react';
import { algorandService } from '../services/algorandService';

interface BlockchainNFTProps {
  isOpen: boolean;
  onClose: () => void;
}

const BlockchainNFT: React.FC<BlockchainNFTProps> = ({ isOpen, onClose }) => {
  const [account, setAccount] = useState<any>(null);
  const [balance, setBalance] = useState<number>(0);
  const [nfts, setNfts] = useState<any[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (isOpen && !account) {
      initializeAccount();
    }
  }, [isOpen]);

  const initializeAccount = async () => {
    try {
      setIsLoading(true);
      const newAccount = algorandService.generateAccount();
      setAccount(newAccount);
      
      const accountBalance = await algorandService.getAccountBalance(newAccount.addr);
      setBalance(accountBalance);
      
      const accountNFTs = await algorandService.getCampaignNFTs(newAccount.addr);
      setNfts(accountNFTs);
    } catch (error) {
      console.error('Failed to initialize Algorand account:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const createCampaignNFT = async () => {
    if (!account) return;
    
    try {
      setIsCreating(true);
      
      const campaignData = {
        title: 'Cruelty-Free Skincare Campaign',
        description: 'Verified ethical marketing campaign promoting cruelty-free beauty products',
        creator: account.addr,
        price: 0,
        metadata: {
          campaign_type: 'influencer_marketing',
          ethical_certification: 'cruelty_free',
          target_audience: 'ethical_consumers',
          platforms: ['instagram', 'tiktok', 'youtube'],
          created_at: new Date().toISOString(),
          verification_status: 'verified'
        }
      };

      const assetId = await algorandService.createCampaignNFT(account, campaignData);
      
      // Add to local NFTs list
      const newNFT = {
        'asset-id': assetId,
        amount: 1,
        metadata: campaignData
      };
      
      setNfts(prev => [...prev, newNFT]);
      
    } catch (error) {
      console.error('Failed to create campaign NFT:', error);
    } finally {
      setIsCreating(false);
    }
  };

  const shareNFT = (nft: any) => {
    const shareData = {
      title: 'Campaign NFT on Algorand',
      text: `Check out this verified campaign NFT: ${nft.metadata?.title || 'Campaign NFT'}`,
      url: `https://testnet.algoexplorer.io/asset/${nft['asset-id']}`
    };
    
    if (navigator.share) {
      navigator.share(shareData);
    } else {
      navigator.clipboard.writeText(shareData.url);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b bg-gradient-to-r from-blue-50 to-purple-50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Coins className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-800">Campaign NFTs on Algorand</h3>
              <p className="text-sm text-slate-600">Blockchain-verified campaign authenticity</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-slate-400" />
          </button>
        </div>

        {isLoading ? (
          <div className="p-12 text-center">
            <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-slate-600">Initializing Algorand account...</p>
          </div>
        ) : (
          <div className="p-6">
            {/* Account Info */}
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <h4 className="text-lg font-semibold text-slate-800">Your Algorand Account</h4>
                <div className="flex items-center gap-2 px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  TestNet Connected
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-slate-600 mb-1">Account Address</p>
                  <p className="font-mono text-xs bg-white p-2 rounded border break-all">
                    {account?.addr || 'Loading...'}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-slate-600 mb-1">Balance</p>
                  <p className="text-lg font-semibold text-slate-800">
                    {(balance / 1000000).toFixed(6)} ALGO
                  </p>
                </div>
              </div>
            </div>

            {/* Create NFT Section */}
            <div className="bg-white border border-slate-200 rounded-xl p-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h4 className="text-lg font-semibold text-slate-800">Create Campaign NFT</h4>
                  <p className="text-sm text-slate-600">Mint a blockchain-verified campaign certificate</p>
                </div>
                <button
                  onClick={createCampaignNFT}
                  disabled={isCreating}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
                >
                  {isCreating ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      Creating...
                    </>
                  ) : (
                    <>
                      <Zap className="h-4 w-4" />
                      Create NFT
                    </>
                  )}
                </button>
              </div>
              
              <div className="bg-slate-50 rounded-lg p-4">
                <h5 className="font-medium text-slate-800 mb-2">Campaign Details</h5>
                <ul className="text-sm text-slate-600 space-y-1">
                  <li>• Campaign: Cruelty-Free Skincare Marketing</li>
                  <li>• Type: Influencer Marketing Campaign</li>
                  <li>• Certification: Ethical & Cruelty-Free Verified</li>
                  <li>• Platforms: Instagram, TikTok, YouTube</li>
                  <li>• Blockchain: Algorand TestNet</li>
                </ul>
              </div>
            </div>

            {/* NFTs Collection */}
            <div>
              <h4 className="text-lg font-semibold text-slate-800 mb-4">Your Campaign NFTs</h4>
              
              {nfts.length === 0 ? (
                <div className="text-center py-12 bg-slate-50 rounded-xl">
                  <Award className="h-12 w-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-500 mb-2">No campaign NFTs yet</p>
                  <p className="text-sm text-slate-400">Create your first blockchain-verified campaign certificate</p>
                </div>
              ) : (
                <div className="grid md:grid-cols-2 gap-4">
                  {nfts.map((nft, index) => (
                    <div key={index} className="border border-slate-200 rounded-xl p-4 hover:border-blue-200 transition-colors">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h5 className="font-medium text-slate-800 mb-1">
                            {nft.metadata?.title || `Campaign NFT #${nft['asset-id']}`}
                          </h5>
                          <p className="text-sm text-slate-600 mb-2">
                            {nft.metadata?.description || 'Blockchain-verified campaign certificate'}
                          </p>
                          <div className="flex items-center gap-2">
                            <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">
                              Asset ID: {nft['asset-id']}
                            </span>
                            <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">
                              Verified
                            </span>
                          </div>
                        </div>
                        <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
                          <Award className="h-8 w-8 text-white" />
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => shareNFT(nft)}
                          className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors text-sm"
                        >
                          <Share2 className="h-4 w-4" />
                          Share
                        </button>
                        <button
                          onClick={() => window.open(`https://testnet.algoexplorer.io/asset/${nft['asset-id']}`, '_blank')}
                          className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-blue-100 hover:bg-blue-200 text-blue-700 rounded-lg transition-colors text-sm"
                        >
                          <Download className="h-4 w-4" />
                          View on Chain
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Info Footer */}
            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Coins className="h-4 w-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-800">Powered by Algorand Blockchain</span>
              </div>
              <p className="text-xs text-blue-600">
                Campaign NFTs provide immutable proof of ethical marketing practices and campaign authenticity. 
                All transactions are recorded on the Algorand blockchain for transparency and verification.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BlockchainNFT;