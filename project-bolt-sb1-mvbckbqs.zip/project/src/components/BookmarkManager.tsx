import React, { useState, useEffect } from 'react';
import { Bookmark, X, Trash2, Star, Calendar, Tag } from 'lucide-react';

interface BookmarkManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface BookmarkItem {
  id: string;
  title: string;
  description: string;
  url: string;
  category: string;
  dateAdded: string;
  isStarred: boolean;
}

const BookmarkManager: React.FC<BookmarkManagerProps> = ({ isOpen, onClose }) => {
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>([]);
  const [filter, setFilter] = useState<string>('all');

  useEffect(() => {
    // Load bookmarks from localStorage
    const savedBookmarks = localStorage.getItem('campaigncraft-bookmarks');
    if (savedBookmarks) {
      setBookmarks(JSON.parse(savedBookmarks));
    }
  }, []);

  const saveBookmarks = (newBookmarks: BookmarkItem[]) => {
    setBookmarks(newBookmarks);
    localStorage.setItem('campaigncraft-bookmarks', JSON.stringify(newBookmarks));
  };

  const addCurrentPageBookmark = () => {
    const newBookmark: BookmarkItem = {
      id: Date.now().toString(),
      title: 'Cruelty-Free Skincare Campaign Brief',
      description: 'Comprehensive influencer marketing strategy for ethical skincare brands',
      url: window.location.href,
      category: 'Campaign Brief',
      dateAdded: new Date().toISOString(),
      isStarred: false
    };

    const updatedBookmarks = [newBookmark, ...bookmarks];
    saveBookmarks(updatedBookmarks);
  };

  const removeBookmark = (id: string) => {
    const updatedBookmarks = bookmarks.filter(bookmark => bookmark.id !== id);
    saveBookmarks(updatedBookmarks);
  };

  const toggleStar = (id: string) => {
    const updatedBookmarks = bookmarks.map(bookmark =>
      bookmark.id === id ? { ...bookmark, isStarred: !bookmark.isStarred } : bookmark
    );
    saveBookmarks(updatedBookmarks);
  };

  const filteredBookmarks = bookmarks.filter(bookmark => {
    if (filter === 'starred') return bookmark.isStarred;
    if (filter === 'recent') return new Date(bookmark.dateAdded) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    return true;
  });

  const categories = ['all', 'starred', 'recent'];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[80vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-100 rounded-lg">
              <Bookmark className="h-5 w-5 text-amber-600" />
            </div>
            <h3 className="text-lg font-semibold text-slate-800">Bookmark Manager</h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-slate-400" />
          </button>
        </div>

        {/* Actions */}
        <div className="p-6 border-b bg-slate-50">
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={addCurrentPageBookmark}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
            >
              <Bookmark className="h-4 w-4" />
              <span>Bookmark This Page</span>
            </button>
            
            <div className="flex items-center gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setFilter(category)}
                  className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                    filter === category
                      ? 'bg-emerald-100 text-emerald-700'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {category.charAt(0).toUpperCase() + category.slice(1)}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Bookmarks List */}
        <div className="flex-1 overflow-y-auto max-h-96">
          {filteredBookmarks.length === 0 ? (
            <div className="p-8 text-center text-slate-500">
              <Bookmark className="h-12 w-12 mx-auto mb-3 text-slate-300" />
              <p className="text-lg font-medium mb-2">No bookmarks yet</p>
              <p className="text-sm">Save important campaign briefs and resources for quick access</p>
            </div>
          ) : (
            <div className="p-4 space-y-3">
              {filteredBookmarks.map((bookmark) => (
                <div
                  key={bookmark.id}
                  className="p-4 border border-slate-200 rounded-lg hover:border-emerald-200 hover:bg-emerald-50/50 transition-all group"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-medium text-slate-800">{bookmark.title}</h4>
                        <span className="px-2 py-1 bg-slate-100 text-slate-600 text-xs rounded-full">
                          {bookmark.category}
                        </span>
                        {bookmark.isStarred && (
                          <Star className="h-4 w-4 text-yellow-500 fill-current" />
                        )}
                      </div>
                      <p className="text-sm text-slate-600 mb-2">{bookmark.description}</p>
                      <div className="flex items-center gap-4 text-xs text-slate-500">
                        <div className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          <span>{new Date(bookmark.dateAdded).toLocaleDateString()}</span>
                        </div>
                        <a
                          href={bookmark.url}
                          className="text-emerald-600 hover:text-emerald-700 transition-colors"
                        >
                          View Page
                        </a>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => toggleStar(bookmark.id)}
                        className={`p-2 rounded-lg transition-colors ${
                          bookmark.isStarred
                            ? 'text-yellow-500 hover:bg-yellow-50'
                            : 'text-slate-400 hover:bg-slate-100'
                        }`}
                      >
                        <Star className={`h-4 w-4 ${bookmark.isStarred ? 'fill-current' : ''}`} />
                      </button>
                      <button
                        onClick={() => removeBookmark(bookmark.id)}
                        className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t bg-slate-50">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>{filteredBookmarks.length} bookmark{filteredBookmarks.length !== 1 ? 's' : ''}</span>
            <span>Bookmarks are saved locally in your browser</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookmarkManager;