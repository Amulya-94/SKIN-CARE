import React, { useState, useEffect } from 'react';
import { Heart, Leaf, Shield, Users, TrendingUp, X, Award } from 'lucide-react';

interface EthicalImpactTrackerProps {
  isOpen: boolean;
  onClose: () => void;
}

const EthicalImpactTracker: React.FC<EthicalImpactTrackerProps> = ({ isOpen, onClose }) => {
  const [impactData, setImpactData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      loadImpactData();
    }
  }, [isOpen]);

  const loadImpactData = async () => {
    setIsLoading(true);
    
    // Simulate loading real impact data
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setImpactData({
      animalsSaved: 1247,
      ethicalBrandsSupported: 23,
      consumerEducation: 89432,
      sustainabilityScore: 94,
      communityGrowth: 156,
      certifications: [
        { name: 'Leaping Bunny Certified', verified: true },
        { name: 'PETA Cruelty-Free', verified: true },
        { name: 'Choose Cruelty Free (CCF)', verified: true },
        { name: 'Cruelty Free International', verified: false }
      ]
    });
    
    setIsLoading(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b bg-gradient-to-r from-emerald-50 to-green-50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-100 rounded-lg">
              <Heart className="h-5 w-5 text-emerald-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-800">Ethical Impact Tracker</h3>
              <p className="text-sm text-slate-600">Measuring your campaign's positive impact on animals and environment</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-slate-400" />
          </button>
        </div>

        {isLoading ? (
          <div className="p-12 text-center">
            <div className="w-12 h-12 border-4 border-emerald-200 border-t-emerald-600 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-slate-600">Calculating ethical impact...</p>
          </div>
        ) : (
          <div className="p-6">
            {/* Impact Overview */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <div className="bg-gradient-to-br from-emerald-50 to-green-50 rounded-xl p-6 text-center">
                <Heart className="h-8 w-8 text-emerald-600 mx-auto mb-3" />
                <div className="text-2xl font-bold text-emerald-600 mb-1">
                  {impactData?.animalsSaved.toLocaleString()}
                </div>
                <div className="text-sm text-slate-600">Animals Protected</div>
                <div className="text-xs text-emerald-600 mt-1">+12% this month</div>
              </div>

              <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl p-6 text-center">
                <Shield className="h-8 w-8 text-blue-600 mx-auto mb-3" />
                <div className="text-2xl font-bold text-blue-600 mb-1">
                  {impactData?.ethicalBrandsSupported}
                </div>
                <div className="text-sm text-slate-600">Ethical Brands Supported</div>
                <div className="text-xs text-blue-600 mt-1">+3 new partnerships</div>
              </div>

              <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6 text-center">
                <Users className="h-8 w-8 text-purple-600 mx-auto mb-3" />
                <div className="text-2xl font-bold text-purple-600 mb-1">
                  {impactData?.consumerEducation.toLocaleString()}
                </div>
                <div className="text-sm text-slate-600">Consumers Educated</div>
                <div className="text-xs text-purple-600 mt-1">+23% engagement</div>
              </div>

              <div className="bg-gradient-to-br from-orange-50 to-yellow-50 rounded-xl p-6 text-center">
                <Leaf className="h-8 w-8 text-orange-600 mx-auto mb-3" />
                <div className="text-2xl font-bold text-orange-600 mb-1">
                  {impactData?.sustainabilityScore}%
                </div>
                <div className="text-sm text-slate-600">Sustainability Score</div>
                <div className="text-xs text-orange-600 mt-1">Industry leading</div>
              </div>
            </div>

            {/* Certifications */}
            <div className="bg-slate-50 rounded-xl p-6 mb-6">
              <h4 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <Award className="h-5 w-5 text-emerald-600" />
                Ethical Certifications
              </h4>
              <div className="grid md:grid-cols-2 gap-4">
                {impactData?.certifications.map((cert: any, index: number) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-white rounded-lg">
                    <span className="font-medium text-slate-800">{cert.name}</span>
                    <div className={`px-2 py-1 rounded-full text-xs ${
                      cert.verified 
                        ? 'bg-emerald-100 text-emerald-700' 
                        : 'bg-slate-100 text-slate-500'
                    }`}>
                      {cert.verified ? 'Verified' : 'Pending'}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Impact Timeline */}
            <div className="bg-white border border-slate-200 rounded-xl p-6">
              <h4 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-blue-600" />
                Impact Growth Over Time
              </h4>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-slate-600">Q1 2024</span>
                  <div className="flex-1 mx-4 bg-slate-200 rounded-full h-2">
                    <div className="bg-emerald-500 h-2 rounded-full" style={{ width: '60%' }}></div>
                  </div>
                  <span className="text-emerald-600 font-semibold">60%</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-slate-600">Q2 2024</span>
                  <div className="flex-1 mx-4 bg-slate-200 rounded-full h-2">
                    <div className="bg-emerald-500 h-2 rounded-full" style={{ width: '75%' }}></div>
                  </div>
                  <span className="text-emerald-600 font-semibold">75%</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-slate-600">Q3 2024</span>
                  <div className="flex-1 mx-4 bg-slate-200 rounded-full h-2">
                    <div className="bg-emerald-500 h-2 rounded-full" style={{ width: '90%' }}></div>
                  </div>
                  <span className="text-emerald-600 font-semibold">90%</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-slate-600">Q4 2024 (Projected)</span>
                  <div className="flex-1 mx-4 bg-slate-200 rounded-full h-2">
                    <div className="bg-gradient-to-r from-emerald-500 to-green-400 h-2 rounded-full" style={{ width: '94%' }}></div>
                  </div>
                  <span className="text-emerald-600 font-semibold">94%</span>
                </div>
              </div>
            </div>

            {/* Call to Action */}
            <div className="mt-6 p-4 bg-gradient-to-r from-emerald-50 to-green-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Heart className="h-4 w-4 text-emerald-600" />
                <span className="text-sm font-medium text-emerald-800">Making a Difference</span>
              </div>
              <p className="text-xs text-emerald-600">
                Your ethical marketing campaigns are creating real positive impact. Every cruelty-free brand 
                promotion helps protect animals and educates consumers about ethical choices.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default EthicalImpactTracker;