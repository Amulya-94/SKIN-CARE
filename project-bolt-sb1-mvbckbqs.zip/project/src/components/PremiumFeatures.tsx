import React, { useState } from 'react';
import { Crown, Zap, Users, BarChart3, Lock, Check } from 'lucide-react';

interface PremiumFeaturesProps {
  onUpgrade: () => void;
}

const PremiumFeatures: React.FC<PremiumFeaturesProps> = ({ onUpgrade }) => {
  const [selectedPlan, setSelectedPlan] = useState<'pro' | 'enterprise'>('pro');

  const plans = {
    pro: {
      name: 'CampaignCraft Pro',
      price: '$29',
      period: '/month',
      features: [
        'Unlimited campaign briefs',
        'Advanced analytics dashboard',
        'AI-powered content suggestions',
        'Voice assistant integration',
        'Priority customer support',
        'Custom branding options',
        'Export to multiple formats',
        'Team collaboration (up to 5 users)'
      ]
    },
    enterprise: {
      name: 'Enterprise',
      price: '$99',
      period: '/month',
      features: [
        'Everything in Pro',
        'Unlimited team members',
        'Advanced integrations',
        'Custom AI training',
        'Dedicated account manager',
        'SLA guarantees',
        'Custom development',
        'White-label solutions'
      ]
    }
  };

  return (
    <div className="bg-gradient-to-br from-purple-50 to-indigo-100 rounded-xl p-8 border border-purple-200">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Crown className="h-8 w-8 text-purple-600" />
          <h2 className="text-2xl font-bold text-slate-800">Unlock Premium Features</h2>
        </div>
        <p className="text-slate-600">Take your influencer marketing to the next level with advanced tools and insights</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6 mb-8">
        {Object.entries(plans).map(([key, plan]) => (
          <div
            key={key}
            className={`p-6 rounded-xl border-2 transition-all cursor-pointer ${
              selectedPlan === key
                ? 'border-purple-500 bg-white shadow-lg'
                : 'border-slate-200 bg-white/50 hover:border-purple-300'
            }`}
            onClick={() => setSelectedPlan(key as 'pro' | 'enterprise')}
          >
            <div className="text-center mb-6">
              <h3 className="text-xl font-bold text-slate-800 mb-2">{plan.name}</h3>
              <div className="flex items-baseline justify-center gap-1">
                <span className="text-3xl font-bold text-purple-600">{plan.price}</span>
                <span className="text-slate-500">{plan.period}</span>
              </div>
            </div>
            
            <ul className="space-y-3">
              {plan.features.map((feature, index) => (
                <li key={index} className="flex items-center gap-3">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span className="text-sm text-slate-600">{feature}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="text-center">
        <button
          onClick={onUpgrade}
          className="px-8 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg font-semibold hover:from-purple-700 hover:to-indigo-700 transition-all shadow-lg"
        >
          <span className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Upgrade to {plans[selectedPlan].name}
          </span>
        </button>
        <p className="text-xs text-slate-500 mt-2">14-day free trial • Cancel anytime</p>
      </div>
    </div>
  );
};

export default PremiumFeatures;