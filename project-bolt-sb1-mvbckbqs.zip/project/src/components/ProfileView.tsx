import React, { useState, useEffect } from 'react';
import { User, Mail, Building, Calendar, Crown, Edit3, X } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface ProfileViewProps {
  isOpen: boolean;
  onClose: () => void;
  user: any;
}

const ProfileView: React.FC<ProfileViewProps> = ({ isOpen, onClose, user }) => {
  const [profile, setProfile] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    full_name: '',
    company: '',
    role: ''
  });

  useEffect(() => {
    if (isOpen && user) {
      loadProfile();
    }
  }, [isOpen, user]);

  const loadProfile = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error loading profile:', error);
      } else if (data) {
        setProfile(data);
        setEditData({
          full_name: data.full_name || '',
          company: data.company || '',
          role: data.role || 'marketing_manager'
        });
      }
    } catch (error) {
      console.error('Error loading profile:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveProfile = async () => {
    try {
      const { error } = await supabase
        .from('profiles')
        .upsert({
          user_id: user.id,
          email: user.email,
          full_name: editData.full_name,
          company: editData.company,
          role: editData.role,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;

      await loadProfile();
      setIsEditing(false);
    } catch (error) {
      console.error('Error saving profile:', error);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b bg-gradient-to-r from-emerald-50 to-blue-50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-100 rounded-lg">
              <User className="h-5 w-5 text-emerald-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-800">Your Profile</h3>
              <p className="text-sm text-slate-600">Manage your account information</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-slate-400" />
          </button>
        </div>

        {isLoading ? (
          <div className="p-12 text-center">
            <div className="w-8 h-8 border-4 border-emerald-200 border-t-emerald-600 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-slate-600">Loading profile...</p>
          </div>
        ) : (
          <div className="p-6">
            {/* Profile Header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-blue-500 rounded-full flex items-center justify-center">
                  <User className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h4 className="text-xl font-semibold text-slate-800">
                    {profile?.full_name || user.email?.split('@')[0] || 'User'}
                  </h4>
                  <p className="text-slate-600">{profile?.company || 'Marketing Professional'}</p>
                  <div className="flex items-center gap-1 mt-1">
                    <Crown className="h-3 w-3 text-purple-600" />
                    <span className="text-xs text-purple-600 font-medium">
                      {profile?.subscription_tier?.toUpperCase() || 'FREE'} Plan
                    </span>
                  </div>
                </div>
              </div>
              
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="flex items-center gap-2 px-3 py-2 bg-emerald-100 hover:bg-emerald-200 text-emerald-700 rounded-lg transition-colors"
              >
                <Edit3 className="h-4 w-4" />
                {isEditing ? 'Cancel' : 'Edit Profile'}
              </button>
            </div>

            {/* Profile Details */}
            <div className="space-y-6">
              {/* Account Information */}
              <div className="bg-slate-50 rounded-xl p-6">
                <h5 className="text-lg font-semibold text-slate-800 mb-4">Account Information</h5>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      <Mail className="inline h-4 w-4 mr-1" />
                      Email Address
                    </label>
                    <div className="p-3 bg-white rounded-lg border">
                      <p className="text-slate-800">{user.email}</p>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      <Calendar className="inline h-4 w-4 mr-1" />
                      Member Since
                    </label>
                    <div className="p-3 bg-white rounded-lg border">
                      <p className="text-slate-800">
                        {new Date(user.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Profile Details */}
              <div className="bg-slate-50 rounded-xl p-6">
                <h5 className="text-lg font-semibold text-slate-800 mb-4">Profile Details</h5>
                
                {isEditing ? (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Full Name
                      </label>
                      <input
                        type="text"
                        value={editData.full_name}
                        onChange={(e) => setEditData({...editData, full_name: e.target.value})}
                        className="w-full p-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        placeholder="Enter your full name"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Company
                      </label>
                      <input
                        type="text"
                        value={editData.company}
                        onChange={(e) => setEditData({...editData, company: e.target.value})}
                        className="w-full p-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        placeholder="Enter your company name"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Role
                      </label>
                      <select
                        value={editData.role}
                        onChange={(e) => setEditData({...editData, role: e.target.value})}
                        className="w-full p-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      >
                        <option value="marketing_manager">Marketing Manager</option>
                        <option value="brand_manager">Brand Manager</option>
                        <option value="social_media_manager">Social Media Manager</option>
                        <option value="content_creator">Content Creator</option>
                        <option value="agency_owner">Agency Owner</option>
                        <option value="freelancer">Freelancer</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    
                    <div className="flex gap-2">
                      <button
                        onClick={handleSaveProfile}
                        className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
                      >
                        Save Changes
                      </button>
                      <button
                        onClick={() => setIsEditing(false)}
                        className="px-4 py-2 bg-slate-200 text-slate-700 rounded-lg hover:bg-slate-300 transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Full Name
                      </label>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-slate-800">{profile?.full_name || 'Not set'}</p>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        <Building className="inline h-4 w-4 mr-1" />
                        Company
                      </label>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-slate-800">{profile?.company || 'Not set'}</p>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Role
                      </label>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-slate-800 capitalize">
                          {profile?.role?.replace('_', ' ') || 'Marketing Manager'}
                        </p>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Subscription
                      </label>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-slate-800 capitalize">
                          {profile?.subscription_tier || 'Free'} Plan
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Usage Statistics */}
              <div className="bg-gradient-to-r from-emerald-50 to-blue-50 rounded-xl p-6">
                <h5 className="text-lg font-semibold text-slate-800 mb-4">Account Statistics</h5>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-emerald-600">1</div>
                    <div className="text-sm text-slate-600">Campaign Briefs</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">0</div>
                    <div className="text-sm text-slate-600">Active Campaigns</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">
                      {Math.floor((Date.now() - new Date(user.created_at).getTime()) / (1000 * 60 * 60 * 24))}
                    </div>
                    <div className="text-sm text-slate-600">Days Active</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfileView;