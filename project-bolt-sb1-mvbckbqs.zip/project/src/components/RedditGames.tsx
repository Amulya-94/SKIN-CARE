import React, { useState, useEffect } from 'react';
import { Gamepad2, X, Trophy, Users, Calendar, ExternalLink } from 'lucide-react';
import { redditService } from '../services/redditService';

interface RedditGamesProps {
  isOpen: boolean;
  onClose: () => void;
}

const RedditGames: React.FC<RedditGamesProps> = ({ isOpen, onClose }) => {
  const [games, setGames] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedGame, setSelectedGame] = useState<any>(null);

  useEffect(() => {
    if (isOpen) {
      loadGames();
    }
  }, [isOpen]);

  const loadGames = async () => {
    try {
      setIsLoading(true);
      const campaignGames = await redditService.getCampaignGames();
      setGames(campaignGames);
    } catch (error) {
      console.error('Failed to load Reddit games:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const joinGame = async (gameId: string) => {
    try {
      const success = await redditService.joinGame(gameId);
      if (success) {
        // Update game participants count
        setGames(prev => prev.map(game => 
          game.id === gameId 
            ? { ...game, participants: game.participants + 1 }
            : game
        ));
      }
    } catch (error) {
      console.error('Failed to join game:', error);
    }
  };

  const createNewGame = async () => {
    try {
      const newGame = await redditService.createCampaignGame({
        title: 'CampaignCraft Pro Challenge',
        description: 'Create the most innovative cruelty-free marketing campaign using CampaignCraft Pro!',
        rules: [
          'Campaign must focus on cruelty-free/ethical products',
          'Use CampaignCraft Pro platform for brief creation',
          'Submit campaign brief and creative assets',
          'Include measurable KPIs and success metrics'
        ],
        prizes: [
          '1 year CampaignCraft Pro subscription',
          '$2000 campaign budget',
          'Featured case study on our platform'
        ]
      });
      
      setGames(prev => [newGame, ...prev]);
    } catch (error) {
      console.error('Failed to create game:', error);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b bg-gradient-to-r from-orange-50 to-red-50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-orange-100 rounded-lg">
              <Gamepad2 className="h-5 w-5 text-orange-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-800">Reddit Campaign Games</h3>
              <p className="text-sm text-slate-600">Silly, creative, and engaging marketing challenges</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-slate-400" />
          </button>
        </div>

        {isLoading ? (
          <div className="p-12 text-center">
            <div className="w-12 h-12 border-4 border-orange-200 border-t-orange-600 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-slate-600">Loading Reddit games...</p>
          </div>
        ) : (
          <div className="p-6">
            {/* Create Game Section */}
            <div className="bg-gradient-to-r from-orange-50 to-red-50 rounded-xl p-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h4 className="text-lg font-semibold text-slate-800">Create Campaign Challenge</h4>
                  <p className="text-sm text-slate-600">Launch a new marketing game on Reddit</p>
                </div>
                <button
                  onClick={createNewGame}
                  className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
                >
                  <Gamepad2 className="h-4 w-4" />
                  Create Game
                </button>
              </div>
              
              <div className="bg-white rounded-lg p-4">
                <h5 className="font-medium text-slate-800 mb-2">Game Ideas</h5>
                <ul className="text-sm text-slate-600 space-y-1">
                  <li>🎯 Best Cruelty-Free Campaign Brief Contest</li>
                  <li>🎨 Most Creative Influencer Outreach Strategy</li>
                  <li>📱 Viral TikTok Campaign Challenge</li>
                  <li>🏆 Ethical Brand Storytelling Competition</li>
                  <li>🎪 Weirdest But Effective Marketing Tactic</li>
                </ul>
              </div>
            </div>

            {/* Active Games */}
            <div>
              <h4 className="text-lg font-semibold text-slate-800 mb-4">Active Campaign Games</h4>
              
              {games.length === 0 ? (
                <div className="text-center py-12 bg-slate-50 rounded-xl">
                  <Gamepad2 className="h-12 w-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-500 mb-2">No active games yet</p>
                  <p className="text-sm text-slate-400">Create the first campaign challenge!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {games.map((game) => (
                    <div key={game.id} className="border border-slate-200 rounded-xl p-6 hover:border-orange-200 transition-colors">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h5 className="text-lg font-semibold text-slate-800">{game.title}</h5>
                            <span className="px-2 py-1 bg-orange-100 text-orange-700 text-xs rounded-full">
                              Active
                            </span>
                          </div>
                          <p className="text-slate-600 mb-3">{game.description}</p>
                          
                          <div className="flex items-center gap-4 text-sm text-slate-500 mb-4">
                            <div className="flex items-center gap-1">
                              <Users className="h-4 w-4" />
                              <span>{game.participants.toLocaleString()} participants</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Trophy className="h-4 w-4" />
                              <span>{game.prizes.length} prizes</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="h-4 w-4" />
                              <span>Ends in 7 days</span>
                            </div>
                          </div>
                        </div>
                        
                        <button
                          onClick={() => joinGame(game.id)}
                          className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
                        >
                          Join Game
                        </button>
                      </div>
                      
                      {/* Game Rules */}
                      <div className="bg-slate-50 rounded-lg p-4 mb-4">
                        <h6 className="font-medium text-slate-800 mb-2">Rules</h6>
                        <ul className="text-sm text-slate-600 space-y-1">
                          {game.rules.map((rule: string, index: number) => (
                            <li key={index}>• {rule}</li>
                          ))}
                        </ul>
                      </div>
                      
                      {/* Prizes */}
                      <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg p-4">
                        <h6 className="font-medium text-slate-800 mb-2 flex items-center gap-2">
                          <Trophy className="h-4 w-4 text-yellow-600" />
                          Prizes
                        </h6>
                        <div className="grid md:grid-cols-3 gap-2">
                          {game.prizes.map((prize: string, index: number) => (
                            <div key={index} className="bg-white rounded p-2 text-sm text-slate-700 text-center">
                              {prize}
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      {/* Actions */}
                      <div className="flex items-center gap-2 mt-4">
                        <button
                          onClick={() => window.open(`https://reddit.com/r/marketing/comments/${game.id}`, '_blank')}
                          className="flex items-center gap-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors text-sm"
                        >
                          <ExternalLink className="h-4 w-4" />
                          View on Reddit
                        </button>
                        <button
                          onClick={() => setSelectedGame(game)}
                          className="flex items-center gap-2 px-3 py-2 bg-orange-100 hover:bg-orange-200 text-orange-700 rounded-lg transition-colors text-sm"
                        >
                          <Gamepad2 className="h-4 w-4" />
                          Game Details
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Info Footer */}
            <div className="mt-6 p-4 bg-orange-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Gamepad2 className="h-4 w-4 text-orange-600" />
                <span className="text-sm font-medium text-orange-800">Powered by Reddit Developer Platform</span>
              </div>
              <p className="text-xs text-orange-600">
                Engage with the marketing community through fun, creative challenges that showcase 
                innovative campaign strategies and ethical marketing practices. Win prizes and build your reputation!
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RedditGames;