import React, { useState, useEffect } from 'react';
import { Search, X, Filter, ChevronRight } from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (sectionId: string) => void;
}

const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose, onNavigate }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);

  const searchableContent = [
    {
      id: 'objectives',
      title: 'Campaign Objectives',
      content: 'Brand awareness, product launch, community engagement, sales conversion, education advocacy, brand trust',
      category: 'Strategy'
    },
    {
      id: 'audience',
      title: 'Target Audience',
      content: 'Demographics, psychographics, age 22-45, ethical consumers, cruelty-free advocates',
      category: 'Audience'
    },
    {
      id: 'messages',
      title: 'Key Brand Messages',
      content: 'Cruelty-free commitment, transparency, ethical sourcing, authentic results',
      category: 'Messaging'
    },
    {
      id: 'content',
      title: 'Content Themes',
      content: 'Educational content, authentic reviews, lifestyle integration, tutorials, testimonials',
      category: 'Content'
    },
    {
      id: 'platforms',
      title: 'Social Media Platforms',
      content: 'Instagram, TikTok, YouTube, visual storytelling, short-form content',
      category: 'Platforms'
    },
    {
      id: 'criteria',
      title: 'Influencer Selection',
      content: 'Follower count, engagement rate, values alignment, authentic voice, professional standards',
      category: 'Selection'
    },
    {
      id: 'timeline',
      title: 'Campaign Timeline',
      content: 'Pre-launch, active campaign, post-campaign, milestones, deliverables',
      category: 'Timeline'
    },
    {
      id: 'metrics',
      title: 'Success Metrics',
      content: 'KPIs, reach, engagement, conversions, awareness metrics, performance tracking',
      category: 'Analytics'
    }
  ];

  useEffect(() => {
    if (searchTerm.length > 0) {
      const results = searchableContent.filter(item =>
        item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.category.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setSearchResults(results);
    } else {
      setSearchResults([]);
    }
  }, [searchTerm]);

  const handleResultClick = (sectionId: string) => {
    onNavigate(sectionId);
    onClose();
    setSearchTerm('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-start justify-center pt-20">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl mx-4 max-h-[80vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center gap-3 p-6 border-b">
          <Search className="h-5 w-5 text-slate-400" />
          <input
            type="text"
            placeholder="Search campaign brief content..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1 text-lg outline-none"
            autoFocus
          />
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-slate-400" />
          </button>
        </div>

        {/* Results */}
        <div className="max-h-96 overflow-y-auto">
          {searchTerm.length === 0 ? (
            <div className="p-6 text-center text-slate-500">
              <Search className="h-12 w-12 mx-auto mb-3 text-slate-300" />
              <p className="text-lg font-medium mb-2">Search Campaign Content</p>
              <p className="text-sm">Find specific sections, metrics, or strategies within the campaign brief</p>
            </div>
          ) : searchResults.length === 0 ? (
            <div className="p-6 text-center text-slate-500">
              <p className="text-lg font-medium mb-2">No results found</p>
              <p className="text-sm">Try searching for objectives, audience, content, or metrics</p>
            </div>
          ) : (
            <div className="p-4">
              <p className="text-sm text-slate-500 mb-4 px-2">
                Found {searchResults.length} result{searchResults.length !== 1 ? 's' : ''}
              </p>
              <div className="space-y-2">
                {searchResults.map((result) => (
                  <button
                    key={result.id}
                    onClick={() => handleResultClick(result.id)}
                    className="w-full text-left p-3 rounded-lg hover:bg-slate-50 transition-colors group"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-slate-800">{result.title}</span>
                          <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-xs rounded-full">
                            {result.category}
                          </span>
                        </div>
                        <p className="text-sm text-slate-600 line-clamp-2">{result.content}</p>
                      </div>
                      <ChevronRight className="h-4 w-4 text-slate-400 group-hover:text-emerald-600 transition-colors" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t bg-slate-50">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Use ↑↓ to navigate, Enter to select</span>
            <span>ESC to close</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SearchModal;