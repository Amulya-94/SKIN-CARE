import React, { useState } from 'react';
import { Share2, X, Copy, Mail, MessageSquare, Link, Check } from 'lucide-react';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState<string | null>(null);

  const shareUrl = window.location.href;
  const shareTitle = "CampaignCraft Pro - Cruelty-Free Skincare Campaign Brief";
  const shareDescription = "Comprehensive influencer marketing strategy for ethical skincare brands";

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy link:', err);
    }
  };

  const handleEmailShare = () => {
    const subject = encodeURIComponent(shareTitle);
    const body = encodeURIComponent(`Check out this comprehensive campaign brief: ${shareDescription}\n\n${shareUrl}`);
    window.open(`mailto:?subject=${subject}&body=${body}`);
    setSelectedMethod('email');
  };

  const handleSocialShare = (platform: string) => {
    const encodedUrl = encodeURIComponent(shareUrl);
    const encodedTitle = encodeURIComponent(shareTitle);
    const encodedDescription = encodeURIComponent(shareDescription);

    let shareLink = '';
    
    switch (platform) {
      case 'linkedin':
        shareLink = `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`;
        break;
      case 'twitter':
        shareLink = `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}`;
        break;
      case 'facebook':
        shareLink = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`;
        break;
    }

    if (shareLink) {
      window.open(shareLink, '_blank', 'width=600,height=400');
      setSelectedMethod(platform);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-100 rounded-lg">
              <Share2 className="h-5 w-5 text-emerald-600" />
            </div>
            <h3 className="text-lg font-semibold text-slate-800">Share Campaign Brief</h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-slate-400" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Copy Link */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Share Link</label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={shareUrl}
                readOnly
                className="flex-1 px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm"
              />
              <button
                onClick={handleCopyLink}
                className={`px-4 py-2 rounded-lg transition-all ${
                  copied 
                    ? 'bg-green-100 text-green-700' 
                    : 'bg-emerald-600 text-white hover:bg-emerald-700'
                }`}
              >
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              </button>
            </div>
            {copied && (
              <p className="text-sm text-green-600 mt-1">Link copied to clipboard!</p>
            )}
          </div>

          {/* Share Methods */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-3">Share via</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={handleEmailShare}
                className={`flex items-center gap-3 p-3 border rounded-lg transition-all ${
                  selectedMethod === 'email'
                    ? 'border-emerald-200 bg-emerald-50'
                    : 'border-slate-200 hover:border-emerald-200 hover:bg-emerald-50'
                }`}
              >
                <Mail className="h-5 w-5 text-slate-600" />
                <span className="font-medium text-slate-700">Email</span>
              </button>

              <button
                onClick={() => handleSocialShare('linkedin')}
                className={`flex items-center gap-3 p-3 border rounded-lg transition-all ${
                  selectedMethod === 'linkedin'
                    ? 'border-blue-200 bg-blue-50'
                    : 'border-slate-200 hover:border-blue-200 hover:bg-blue-50'
                }`}
              >
                <div className="w-5 h-5 bg-blue-600 rounded"></div>
                <span className="font-medium text-slate-700">LinkedIn</span>
              </button>

              <button
                onClick={() => handleSocialShare('twitter')}
                className={`flex items-center gap-3 p-3 border rounded-lg transition-all ${
                  selectedMethod === 'twitter'
                    ? 'border-sky-200 bg-sky-50'
                    : 'border-slate-200 hover:border-sky-200 hover:bg-sky-50'
                }`}
              >
                <div className="w-5 h-5 bg-sky-500 rounded"></div>
                <span className="font-medium text-slate-700">Twitter</span>
              </button>

              <button
                onClick={() => handleSocialShare('facebook')}
                className={`flex items-center gap-3 p-3 border rounded-lg transition-all ${
                  selectedMethod === 'facebook'
                    ? 'border-blue-200 bg-blue-50'
                    : 'border-slate-200 hover:border-blue-200 hover:bg-blue-50'
                }`}
              >
                <div className="w-5 h-5 bg-blue-700 rounded"></div>
                <span className="font-medium text-slate-700">Facebook</span>
              </button>
            </div>
          </div>

          {/* Additional Options */}
          <div className="pt-4 border-t">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-600">Campaign Brief Access</span>
              <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full font-medium">
                Public
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Anyone with the link can view this campaign brief
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShareModal;