import React, { useState, useEffect, useRef } from 'react';
import { Video, VideoOff, MessageCircle, X, Loader } from 'lucide-react';
import { tavusService } from '../services/tavusService';

interface TavusVideoAgentProps {
  isOpen: boolean;
  onClose: () => void;
}

const TavusVideoAgent: React.FC<TavusVideoAgentProps> = ({ isOpen, onClose }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [conversation, setConversation] = useState<any>(null);
  const [messages, setMessages] = useState<Array<{id: string, text: string, sender: 'user' | 'agent'}>>([]);
  const [isDemoMode, setIsDemoMode] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (isOpen && !conversation) {
      initializeVideoAgent();
    }
  }, [isOpen]);

  const initializeVideoAgent = async () => {
    setIsLoading(true);
    try {
      // Check if we have a valid API key
      const hasApiKey = !!import.meta.env.VITE_TAVUS_API_KEY;
      
      if (!hasApiKey) {
        console.log('Tavus API key not configured, running in demo mode');
        setIsDemoMode(true);
      }

      const config = {
        persona_id: 'demo_persona_id',
        conversation_config: {
          properties: {
            campaign_context: 'cruelty_free_skincare',
            user_role: 'marketing_manager'
          }
        }
      };

      const newConversation = await tavusService.createConversation(config);
      setConversation(newConversation);
      setIsConnected(true);
      
      // Add welcome message
      const welcomeText = isDemoMode || !import.meta.env.VITE_TAVUS_API_KEY
        ? "Hi! I'm your AI campaign advisor (Demo Mode). I can help you optimize your cruelty-free skincare campaign strategy. What would you like to discuss?"
        : "Hi! I'm your AI campaign advisor. I can help you optimize your cruelty-free skincare campaign strategy. What would you like to discuss?";
      
      setMessages([{
        id: '1',
        text: welcomeText,
        sender: 'agent'
      }]);
    } catch (error) {
      console.error('Failed to initialize Tavus video agent:', error);
      // Always fall back to demo mode on error
      setIsDemoMode(true);
      setIsConnected(true);
      setMessages([{
        id: '1',
        text: "Hi! I'm your AI campaign advisor (Demo Mode). I can help you optimize your cruelty-free skincare campaign strategy. What would you like to discuss?",
        sender: 'agent'
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const sendMessage = (text: string) => {
    const userMessage = {
      id: Date.now().toString(),
      text,
      sender: 'user' as const
    };
    
    setMessages(prev => [...prev, userMessage]);
    
    // Simulate AI response
    setTimeout(() => {
      const response = generateAIResponse(text);
      const agentMessage = {
        id: (Date.now() + 1).toString(),
        text: response,
        sender: 'agent' as const
      };
      setMessages(prev => [...prev, agentMessage]);
    }, 1000);
  };

  const generateAIResponse = (userInput: string): string => {
    const input = userInput.toLowerCase();
    
    if (input.includes('influencer') || input.includes('selection')) {
      return "For cruelty-free campaigns, I recommend focusing on micro-influencers with 10K-100K followers who genuinely use ethical products. Look for authentic engagement rates above 3.5% and values alignment with animal welfare.";
    } else if (input.includes('content') || input.includes('creative')) {
      return "Effective content themes include ingredient education, behind-the-scenes brand transparency, authentic before/after results, and lifestyle integration. User-generated content performs 4x better than brand-created content in this space.";
    } else if (input.includes('budget') || input.includes('cost')) {
      return "For cruelty-free campaigns, allocate 60% to influencer fees, 25% to content creation, and 15% to paid amplification. Micro-influencers typically charge $100-500 per 10K followers for dedicated posts.";
    } else if (input.includes('platform') || input.includes('social')) {
      return "Instagram and TikTok are primary platforms for beauty campaigns. Instagram for detailed product education and TikTok for viral trends. YouTube works well for in-depth reviews and tutorials.";
    } else {
      return "That's a great question! I can provide insights on influencer selection, content strategy, budget optimization, platform selection, and campaign performance metrics. What specific area would you like to explore?";
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl h-[80vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b bg-gradient-to-r from-purple-50 to-blue-50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Video className="h-5 w-5 text-purple-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-800">AI Campaign Advisor</h3>
              <p className="text-sm text-slate-600">
                Powered by Tavus Conversational AI {isDemoMode && '(Demo Mode)'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-slate-400" />
          </button>
        </div>

        <div className="flex-1 flex">
          {/* Video Section */}
          <div className="w-1/2 bg-slate-900 relative">
            {isLoading ? (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center text-white">
                  <Loader className="h-8 w-8 animate-spin mx-auto mb-2" />
                  <p>Initializing AI Agent...</p>
                </div>
              </div>
            ) : isConnected ? (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center text-white">
                  <div className="w-32 h-32 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <Video className="h-16 w-16" />
                  </div>
                  <p className="text-lg font-medium">AI Campaign Advisor</p>
                  <p className="text-sm text-slate-300">
                    {isDemoMode ? 'Demo Mode - Ready to help' : 'Ready to help optimize your campaign'}
                  </p>
                </div>
              </div>
            ) : (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center text-white">
                  <VideoOff className="h-16 w-16 mx-auto mb-4 text-slate-400" />
                  <p>Video agent unavailable</p>
                </div>
              </div>
            )}
            
            {/* Connection Status */}
            <div className="absolute top-4 left-4">
              <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-sm ${
                isConnected ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'
              }`}>
                <div className={`w-2 h-2 rounded-full ${
                  isConnected ? 'bg-green-400 animate-pulse' : 'bg-red-400'
                }`}></div>
                <span>{isConnected ? (isDemoMode ? 'Demo Mode' : 'Connected') : 'Disconnected'}</span>
              </div>
            </div>
          </div>

          {/* Chat Section */}
          <div className="w-1/2 flex flex-col">
            {/* Messages */}
            <div className="flex-1 p-4 overflow-y-auto space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-lg ${
                      message.sender === 'user'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 text-slate-800'
                    }`}
                  >
                    <p className="text-sm">{message.text}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Quick Actions */}
            <div className="p-4 border-t bg-slate-50">
              <p className="text-xs text-slate-500 mb-2">Quick questions:</p>
              <div className="flex flex-wrap gap-2">
                {[
                  'How to select influencers?',
                  'Content strategy tips?',
                  'Budget recommendations?',
                  'Platform selection?'
                ].map((question) => (
                  <button
                    key={question}
                    onClick={() => sendMessage(question)}
                    className="px-3 py-1 bg-white border border-slate-200 rounded-full text-xs hover:bg-emerald-50 hover:border-emerald-200 transition-colors"
                  >
                    {question}
                  </button>
                ))}
              </div>
            </div>

            {/* Input */}
            <div className="p-4 border-t">
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Ask about campaign strategy..."
                  className="flex-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && e.currentTarget.value.trim()) {
                      sendMessage(e.currentTarget.value);
                      e.currentTarget.value = '';
                    }
                  }}
                />
                <button className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors">
                  <MessageCircle className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TavusVideoAgent;