import React, { useState } from 'react';
import { User, Settings, LogOut, Crown, ChevronDown } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface UserMenuProps {
  user: any;
  onSignOut: () => void;
}

const UserMenu: React.FC<UserMenuProps> = ({ user, onSignOut }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      onSignOut();
      setIsOpen(false);
    } catch (error) {
      console.error('Sign out error:', error);
    }
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 p-2 rounded-lg hover:bg-slate-100 transition-colors"
      >
        <div className="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center">
          <User className="h-4 w-4 text-emerald-600" />
        </div>
        <div className="hidden md:block text-left">
          <p className="text-sm font-medium text-slate-800">
            {user.user_metadata?.full_name || user.email?.split('@')[0] || 'User'}
          </p>
          <p className="text-xs text-slate-500">
            {user.user_metadata?.company || 'Marketing Professional'}
          </p>
        </div>
        <ChevronDown className="h-4 w-4 text-slate-400" />
      </button>

      {isOpen && (
        <>
          <div 
            className="fixed inset-0 z-10" 
            onClick={() => setIsOpen(false)}
          ></div>
          <div className="absolute right-0 top-full mt-2 w-64 bg-white rounded-lg shadow-lg border border-slate-200 z-20">
            <div className="p-4 border-b border-slate-200">
              <p className="font-medium text-slate-800">
                {user.user_metadata?.full_name || 'User'}
              </p>
              <p className="text-sm text-slate-500">{user.email}</p>
              <div className="flex items-center gap-1 mt-2">
                <Crown className="h-3 w-3 text-purple-600" />
                <span className="text-xs text-purple-600 font-medium">Free Plan</span>
              </div>
            </div>
            
            <div className="p-2">
              <button className="w-full flex items-center gap-3 p-2 text-left hover:bg-slate-50 rounded-lg transition-colors">
                <Settings className="h-4 w-4 text-slate-400" />
                <span className="text-sm text-slate-700">Account Settings</span>
              </button>
              
              <button className="w-full flex items-center gap-3 p-2 text-left hover:bg-slate-50 rounded-lg transition-colors">
                <Crown className="h-4 w-4 text-purple-600" />
                <span className="text-sm text-slate-700">Upgrade to Pro</span>
              </button>
              
              <hr className="my-2" />
              
              <button
                onClick={handleSignOut}
                className="w-full flex items-center gap-3 p-2 text-left hover:bg-red-50 rounded-lg transition-colors text-red-600"
              >
                <LogOut className="h-4 w-4" />
                <span className="text-sm">Sign Out</span>
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default UserMenu;