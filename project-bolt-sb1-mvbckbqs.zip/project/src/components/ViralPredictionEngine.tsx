import React, { useState, useEffect } from 'react';
import { Zap, TrendingUp, Target, Users, Clock, X, Sparkles, BarChart3 } from 'lucide-react';

interface ViralPredictionEngineProps {
  isOpen: boolean;
  onClose: () => void;
}

const ViralPredictionEngine: React.FC<ViralPredictionEngineProps> = ({ isOpen, onClose }) => {
  const [prediction, setPrediction] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  useEffect(() => {
    if (isOpen) {
      runViralAnalysis();
    }
  }, [isOpen]);

  const runViralAnalysis = async () => {
    setIsAnalyzing(true);
    
    // Simulate AI analysis
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    setPrediction({
      viralScore: 87,
      peakTime: '2-4 days',
      expectedReach: 2400000,
      engagementRate: 8.3,
      shareability: 92,
      factors: [
        { name: 'Trending Topic Alignment', score: 94, impact: 'High' },
        { name: 'Emotional Resonance', score: 89, impact: 'High' },
        { name: 'Visual Appeal', score: 91, impact: 'Medium' },
        { name: 'Timing Optimization', score: 76, impact: 'Medium' },
        { name: 'Influencer Network Effect', score: 88, impact: 'High' }
      ],
      recommendations: [
        'Post during peak engagement hours (6-8 PM EST)',
        'Include trending hashtag #CleanBeautyRevolution',
        'Add emotional storytelling element about animal welfare',
        'Create shareable infographic about cruelty-free facts'
      ]
    });
    
    setIsAnalyzing(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b bg-gradient-to-r from-orange-50 to-red-50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-orange-100 rounded-lg">
              <Zap className="h-5 w-5 text-orange-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-800">Viral Prediction Engine</h3>
              <p className="text-sm text-slate-600">AI-powered virality analysis and optimization</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-slate-400" />
          </button>
        </div>

        {isAnalyzing ? (
          <div className="p-12 text-center">
            <div className="relative w-16 h-16 mx-auto mb-6">
              <div className="absolute inset-0 border-4 border-orange-200 rounded-full"></div>
              <div className="absolute inset-0 border-4 border-orange-600 rounded-full border-t-transparent animate-spin"></div>
              <Sparkles className="absolute inset-0 m-auto h-6 w-6 text-orange-600" />
            </div>
            <p className="text-slate-600 mb-2">Analyzing viral potential...</p>
            <p className="text-sm text-slate-500">Processing social signals, trends, and engagement patterns</p>
          </div>
        ) : prediction ? (
          <div className="p-6">
            {/* Viral Score */}
            <div className="bg-gradient-to-r from-orange-50 to-red-50 rounded-xl p-6 mb-6">
              <div className="text-center mb-6">
                <div className="relative w-32 h-32 mx-auto mb-4">
                  <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 120 120">
                    <circle
                      cx="60"
                      cy="60"
                      r="50"
                      stroke="#fed7aa"
                      strokeWidth="8"
                      fill="none"
                    />
                    <circle
                      cx="60"
                      cy="60"
                      r="50"
                      stroke="#ea580c"
                      strokeWidth="8"
                      fill="none"
                      strokeDasharray={`${prediction.viralScore * 3.14} 314`}
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-orange-600">{prediction.viralScore}</div>
                      <div className="text-xs text-slate-600">Viral Score</div>
                    </div>
                  </div>
                </div>
                <h4 className="text-lg font-semibold text-slate-800 mb-2">High Viral Potential</h4>
                <p className="text-slate-600">Your campaign has excellent chances of going viral</p>
              </div>

              <div className="grid md:grid-cols-4 gap-4">
                <div className="text-center">
                  <Clock className="h-6 w-6 text-orange-600 mx-auto mb-2" />
                  <div className="font-semibold text-slate-800">{prediction.peakTime}</div>
                  <div className="text-xs text-slate-600">Peak Time</div>
                </div>
                <div className="text-center">
                  <Users className="h-6 w-6 text-orange-600 mx-auto mb-2" />
                  <div className="font-semibold text-slate-800">{(prediction.expectedReach / 1000000).toFixed(1)}M</div>
                  <div className="text-xs text-slate-600">Expected Reach</div>
                </div>
                <div className="text-center">
                  <TrendingUp className="h-6 w-6 text-orange-600 mx-auto mb-2" />
                  <div className="font-semibold text-slate-800">{prediction.engagementRate}%</div>
                  <div className="text-xs text-slate-600">Engagement Rate</div>
                </div>
                <div className="text-center">
                  <Target className="h-6 w-6 text-orange-600 mx-auto mb-2" />
                  <div className="font-semibold text-slate-800">{prediction.shareability}%</div>
                  <div className="text-xs text-slate-600">Shareability</div>
                </div>
              </div>
            </div>

            {/* Viral Factors */}
            <div className="bg-white border border-slate-200 rounded-xl p-6 mb-6">
              <h4 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-blue-600" />
                Viral Success Factors
              </h4>
              
              <div className="space-y-4">
                {prediction.factors.map((factor: any, index: number) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-slate-800">{factor.name}</span>
                        <div className="flex items-center gap-2">
                          <span className={`px-2 py-1 text-xs rounded-full ${
                            factor.impact === 'High' 
                              ? 'bg-red-100 text-red-700' 
                              : 'bg-yellow-100 text-yellow-700'
                          }`}>
                            {factor.impact}
                          </span>
                          <span className="text-sm font-semibold text-slate-700">{factor.score}%</span>
                        </div>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-2">
                        <div 
                          className="bg-gradient-to-r from-orange-500 to-red-500 h-2 rounded-full transition-all duration-1000"
                          style={{ width: `${factor.score}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Optimization Recommendations */}
            <div className="bg-gradient-to-r from-emerald-50 to-green-50 rounded-xl p-6">
              <h4 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-emerald-600" />
                Viral Optimization Tips
              </h4>
              
              <div className="space-y-3">
                {prediction.recommendations.map((rec: string, index: number) => (
                  <div key={index} className="flex items-start gap-3 p-3 bg-white rounded-lg">
                    <div className="w-6 h-6 bg-emerald-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs font-semibold text-emerald-600">{index + 1}</span>
                    </div>
                    <p className="text-slate-700">{rec}</p>
                  </div>
                ))}
              </div>
              
              <div className="mt-4 p-3 bg-emerald-100 rounded-lg">
                <p className="text-sm text-emerald-700">
                  <strong>Pro Tip:</strong> Implementing these recommendations could increase your viral score by up to 15 points!
                </p>
              </div>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
};

export default ViralPredictionEngine;