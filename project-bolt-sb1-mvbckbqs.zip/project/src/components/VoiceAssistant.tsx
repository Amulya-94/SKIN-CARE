import React, { useState, useRef } from 'react';
import { Mic, MicOff, Volume2, VolumeX, Zap } from 'lucide-react';
import { elevenLabsService } from '../services/elevenLabsService';

interface VoiceAssistantProps {
  onVoiceCommand: (command: string) => void;
}

const VoiceAssistant: React.FC<VoiceAssistantProps> = ({ onVoiceCommand }) => {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  const startListening = () => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onstart = () => {
        setIsListening(true);
      };

      recognitionRef.current.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        onVoiceCommand(transcript);
        handleVoiceResponse(transcript);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current.start();
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
  };

  const handleVoiceResponse = async (command: string) => {
    setIsProcessing(true);
    try {
      const response = generateResponse(command);
      await speakWithElevenLabs(response);
    } catch (error) {
      console.error('Voice response error:', error);
      // Fallback to browser speech synthesis
      await speakWithBrowser(generateResponse(command));
    } finally {
      setIsProcessing(false);
    }
  };

  const speakWithElevenLabs = async (text: string) => {
    try {
      setIsSpeaking(true);
      const audioBuffer = await elevenLabsService.generateSpeech(text);
      elevenLabsService.playAudio(audioBuffer);
      
      // Estimate speech duration (rough calculation)
      const estimatedDuration = text.length * 50; // ~50ms per character
      setTimeout(() => setIsSpeaking(false), estimatedDuration);
    } catch (error) {
      console.error('ElevenLabs speech error:', error);
      throw error;
    }
  };

  const speakWithBrowser = async (text: string) => {
    if ('speechSynthesis' in window) {
      setIsSpeaking(true);
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.onend = () => setIsSpeaking(false);
      speechSynthesis.speak(utterance);
    }
  };

  const generateResponse = (command: string): string => {
    const lowerCommand = command.toLowerCase();
    
    if (lowerCommand.includes('objective')) {
      return "The main campaign objectives include increasing brand awareness by 35%, driving sales conversion by 25%, and building an engaged community of ethical consumers through authentic storytelling.";
    } else if (lowerCommand.includes('audience')) {
      return "The target audience consists of ethically-minded consumers aged 22 to 45, primarily female, with college education and income between 40K to 100K dollars who value transparency and cruelty-free practices.";
    } else if (lowerCommand.includes('platform')) {
      return "The primary platforms are Instagram for visual storytelling and TikTok for short-form educational content, with YouTube as a secondary platform for detailed reviews and tutorials.";
    } else if (lowerCommand.includes('timeline')) {
      return "The campaign runs for 10 weeks total: 2 weeks pre-launch for preparation, 6 weeks active campaign for content creation, and 2 weeks post-campaign for analysis and optimization.";
    } else if (lowerCommand.includes('budget') || lowerCommand.includes('cost')) {
      return "The campaign budget includes influencer fees, content creation costs, and platform advertising spend, with flexible pricing based on influencer tier and engagement rates.";
    } else if (lowerCommand.includes('metric') || lowerCommand.includes('kpi')) {
      return "Success metrics include reach of 2 million plus, engagement rate above 4.5%, click-through rate of 2.5%, and conversion rate of 3% with positive sentiment analysis.";
    } else {
      return "I'm your AI campaign assistant powered by ElevenLabs. I can help you navigate through objectives, audience targeting, platform strategies, timelines, budgets, and success metrics. What would you like to know?";
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <div className="flex flex-col items-end gap-2">
        {(isListening || isSpeaking || isProcessing) && (
          <div className="bg-white rounded-lg shadow-lg p-3 border max-w-xs">
            <div className="flex items-center gap-2 text-sm">
              {isListening && (
                <>
                  <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                  <span className="text-slate-600">Listening...</span>
                </>
              )}
              {isProcessing && (
                <>
                  <Zap className="h-4 w-4 text-blue-600 animate-pulse" />
                  <span className="text-slate-600">Processing with ElevenLabs...</span>
                </>
              )}
              {isSpeaking && (
                <>
                  <Volume2 className="h-4 w-4 text-emerald-600 animate-pulse" />
                  <span className="text-slate-600">Speaking with AI voice...</span>
                </>
              )}
            </div>
          </div>
        )}
        
        <div className="flex items-center gap-2">
          <div className="bg-white rounded-lg shadow-lg p-2 border">
            <div className="flex items-center gap-1 text-xs text-slate-500">
              <Zap className="h-3 w-3 text-blue-600" />
              <span>ElevenLabs AI</span>
            </div>
          </div>
          
          <button
            onClick={isListening ? stopListening : startListening}
            disabled={isProcessing}
            className={`p-4 rounded-full shadow-lg transition-all ${
              isListening 
                ? 'bg-red-500 hover:bg-red-600 text-white' 
                : isProcessing
                ? 'bg-blue-500 text-white cursor-not-allowed'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white'
            }`}
          >
            {isProcessing ? (
              <Zap className="h-6 w-6 animate-spin" />
            ) : isListening ? (
              <MicOff className="h-6 w-6" />
            ) : (
              <Mic className="h-6 w-6" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default VoiceAssistant;