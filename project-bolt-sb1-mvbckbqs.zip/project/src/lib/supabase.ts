import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Database schema for campaign briefs
export interface CampaignBrief {
  id: string
  title: string
  brand_name: string
  campaign_type: string
  target_audience: any
  objectives: any
  content_themes: any
  timeline: any
  budget: number
  created_at: string
  updated_at: string
  user_id: string
}

// Campaign brief operations
export const campaignBriefService = {
  async createBrief(brief: Omit<CampaignBrief, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('campaign_briefs')
      .insert([brief])
      .select()
    
    if (error) throw error
    return data[0]
  },

  async getBriefs(userId: string) {
    const { data, error } = await supabase
      .from('campaign_briefs')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
    
    if (error) throw error
    return data
  },

  async updateBrief(id: string, updates: Partial<CampaignBrief>) {
    const { data, error } = await supabase
      .from('campaign_briefs')
      .update(updates)
      .eq('id', id)
      .select()
    
    if (error) throw error
    return data[0]
  },

  async deleteBrief(id: string) {
    const { error } = await supabase
      .from('campaign_briefs')
      .delete()
      .eq('id', id)
    
    if (error) throw error
  }
}