import algosdk from 'algosdk';

interface CampaignNFT {
  id: number;
  title: string;
  description: string;
  creator: string;
  price: number;
  metadata: any;
}

class AlgorandService {
  private algodClient: algosdk.Algodv2;
  private indexerClient: algosdk.Indexer;

  constructor() {
    // Using Algorand TestNet
    const algodToken = '';
    const algodServer = 'https://testnet-api.algonode.cloud';
    const algodPort = 443;

    const indexerToken = '';
    const indexerServer = 'https://testnet-idx.algonode.cloud';
    const indexerPort = 443;

    this.algodClient = new algosdk.Algodv2(algodToken, algodServer, algodPort);
    this.indexerClient = new algosdk.Indexer(indexerToken, indexerServer, indexerPort);
  }

  async createCampaignNFT(
    creatorAccount: algosdk.Account,
    campaignData: Omit<CampaignNFT, 'id'>
  ): Promise<number> {
    try {
      const suggestedParams = await this.algodClient.getTransactionParams().do();
      
      const metadata = {
        name: campaignData.title,
        description: campaignData.description,
        image: 'https://via.placeholder.com/400x400?text=Campaign+NFT',
        properties: campaignData.metadata
      };

      const txn = algosdk.makeAssetCreateTxnWithSuggestedParamsFromObject({
        from: creatorAccount.addr,
        suggestedParams,
        defaultFrozen: false,
        unitName: 'CAMP',
        assetName: campaignData.title,
        manager: creatorAccount.addr,
        reserve: creatorAccount.addr,
        freeze: creatorAccount.addr,
        clawback: creatorAccount.addr,
        assetURL: `ipfs://campaign-metadata-${Date.now()}`,
        assetMetadataHash: new Uint8Array(32), // In production, use actual metadata hash
        total: 1,
        decimals: 0
      });

      const signedTxn = txn.signTxn(creatorAccount.sk);
      const { txId } = await this.algodClient.sendRawTransaction(signedTxn).do();
      
      const result = await algosdk.waitForConfirmation(this.algodClient, txId, 4);
      return result['asset-index'];
    } catch (error) {
      console.error('Failed to create campaign NFT:', error);
      throw error;
    }
  }

  async transferCampaignNFT(
    fromAccount: algosdk.Account,
    toAddress: string,
    assetId: number,
    amount: number = 1
  ): Promise<string> {
    try {
      const suggestedParams = await this.algodClient.getTransactionParams().do();
      
      const txn = algosdk.makeAssetTransferTxnWithSuggestedParamsFromObject({
        from: fromAccount.addr,
        to: toAddress,
        assetIndex: assetId,
        amount,
        suggestedParams
      });

      const signedTxn = txn.signTxn(fromAccount.sk);
      const { txId } = await this.algodClient.sendRawTransaction(signedTxn).do();
      
      await algosdk.waitForConfirmation(this.algodClient, txId, 4);
      return txId;
    } catch (error) {
      console.error('Failed to transfer campaign NFT:', error);
      throw error;
    }
  }

  async getCampaignNFTs(ownerAddress: string): Promise<any[]> {
    try {
      const accountInfo = await this.indexerClient
        .lookupAccountByID(ownerAddress)
        .do();
      
      return accountInfo.account.assets || [];
    } catch (error) {
      console.error('Failed to get campaign NFTs:', error);
      return [];
    }
  }

  generateAccount(): algosdk.Account {
    return algosdk.generateAccount();
  }

  async getAccountBalance(address: string): Promise<number> {
    try {
      const accountInfo = await this.algodClient.accountInformation(address).do();
      return accountInfo.amount;
    } catch (error) {
      console.error('Failed to get account balance:', error);
      return 0;
    }
  }
}

export const algorandService = new AlgorandService();