interface RedditPost {
  title: string;
  content: string;
  subreddit: string;
  flair?: string;
}

interface RedditGame {
  id: string;
  title: string;
  description: string;
  rules: string[];
  participants: number;
  prizes: string[];
}

class RedditService {
  private clientId: string;
  private clientSecret: string;
  private userAgent: string;
  private accessToken: string | null = null;

  constructor() {
    this.clientId = import.meta.env.VITE_REDDIT_CLIENT_ID || '';
    this.clientSecret = import.meta.env.VITE_REDDIT_CLIENT_SECRET || '';
    this.userAgent = 'CampaignCraft-Pro/1.0';
  }

  async authenticate() {
    if (!this.clientId || !this.clientSecret) {
      throw new Error('Reddit API credentials not configured');
    }

    try {
      const auth = btoa(`${this.clientId}:${this.clientSecret}`);
      const response = await fetch('https://www.reddit.com/api/v1/access_token', {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
          'User-Agent': this.userAgent
        },
        body: 'grant_type=client_credentials'
      });

      if (!response.ok) {
        throw new Error(`Reddit auth failed: ${response.statusText}`);
      }

      const data = await response.json();
      this.accessToken = data.access_token;
      return this.accessToken;
    } catch (error) {
      console.error('Reddit authentication failed:', error);
      throw error;
    }
  }

  async createCampaignGame(gameData: Omit<RedditGame, 'id' | 'participants'>): Promise<RedditGame> {
    // Simulate creating a campaign-themed game on Reddit
    const game: RedditGame = {
      id: `game_${Date.now()}`,
      participants: 0,
      ...gameData
    };

    // In a real implementation, this would create actual Reddit posts/games
    console.log('Created Reddit campaign game:', game);
    return game;
  }

  async postCampaignContent(post: RedditPost): Promise<string> {
    if (!this.accessToken) {
      await this.authenticate();
    }

    try {
      // Simulate posting campaign content to Reddit
      const postId = `post_${Date.now()}`;
      console.log('Posted to Reddit:', { postId, ...post });
      return postId;
    } catch (error) {
      console.error('Failed to post to Reddit:', error);
      throw error;
    }
  }

  async getCampaignGames(): Promise<RedditGame[]> {
    // Simulate fetching campaign games from Reddit
    return [
      {
        id: 'game_1',
        title: 'Cruelty-Free Beauty Challenge',
        description: 'Share your favorite cruelty-free beauty routine and win amazing prizes!',
        rules: [
          'Must use only cruelty-free products',
          'Include before/after photos',
          'Tag 3 friends who care about ethical beauty'
        ],
        participants: 1247,
        prizes: ['$500 beauty bundle', 'Featured brand collaboration', 'Exclusive product early access']
      },
      {
        id: 'game_2',
        title: 'Ethical Influencer Spotlight',
        description: 'Nominate influencers who promote ethical brands and practices',
        rules: [
          'Influencer must have 10K+ followers',
          'Must promote ethical/sustainable brands',
          'Include examples of their ethical content'
        ],
        participants: 892,
        prizes: ['Influencer collaboration opportunity', '$1000 campaign budget', 'Brand partnership']
      }
    ];
  }

  async joinGame(gameId: string): Promise<boolean> {
    try {
      // Simulate joining a Reddit game
      console.log(`Joined Reddit game: ${gameId}`);
      return true;
    } catch (error) {
      console.error('Failed to join game:', error);
      return false;
    }
  }
}

export const redditService = new RedditService();