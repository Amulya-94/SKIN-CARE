import { Purchases, PurchasesOffering, CustomerInfo } from '@revenuecat/purchases-capacitor';

class RevenueCatService {
  private isInitialized = false;
  private isCapacitorEnvironment = false;

  constructor() {
    // Check if we're in a Capacitor environment
    this.isCapacitorEnvironment = !!(window as any).Capacitor;
  }

  async initialize() {
    if (this.isInitialized) return;

    // Only initialize RevenueCat in Capacitor environments
    if (!this.isCapacitorEnvironment) {
      console.log('RevenueCat: Running in web environment, using mock data');
      this.isInitialized = true;
      return;
    }

    const apiKey = import.meta.env.VITE_REVENUECAT_API_KEY;
    if (!apiKey) {
      throw new Error('RevenueCat API key not configured');
    }

    try {
      await Purchases.configure({ apiKey });
      this.isInitialized = true;
    } catch (error) {
      console.error('RevenueCat initialization failed:', error);
      throw error;
    }
  }

  async getOfferings(): Promise<PurchasesOffering[]> {
    await this.initialize();
    
    // Return mock offerings for web environment
    if (!this.isCapacitorEnvironment) {
      return this.getMockOfferings();
    }
    
    try {
      const offerings = await Purchases.getOfferings();
      return offerings.all ? Object.values(offerings.all) : [];
    } catch (error) {
      console.error('Failed to get offerings:', error);
      return this.getMockOfferings();
    }
  }

  private getMockOfferings(): PurchasesOffering[] {
    // Return mock offerings for development/web environment
    return [
      {
        identifier: 'pro',
        serverDescription: 'CampaignCraft Pro Monthly',
        metadata: null,
        availablePackages: [{
          identifier: 'pro_monthly',
          packageType: 'MONTHLY',
          product: {
            identifier: 'pro_monthly',
            description: 'CampaignCraft Pro Monthly Subscription',
            title: 'Pro Monthly',
            price: 29.99,
            priceString: '$29.99',
            currencyCode: 'USD',
            introPrice: null,
            discounts: []
          },
          offeringIdentifier: 'pro'
        }]
      } as PurchasesOffering,
      {
        identifier: 'enterprise',
        serverDescription: 'CampaignCraft Enterprise Monthly',
        metadata: null,
        availablePackages: [{
          identifier: 'enterprise_monthly',
          packageType: 'MONTHLY',
          product: {
            identifier: 'enterprise_monthly',
            description: 'CampaignCraft Enterprise Monthly Subscription',
            title: 'Enterprise Monthly',
            price: 99.99,
            priceString: '$99.99',
            currencyCode: 'USD',
            introPrice: null,
            discounts: []
          },
          offeringIdentifier: 'enterprise'
        }]
      } as PurchasesOffering
    ];
  }

  async purchasePackage(packageToPurchase: any) {
    await this.initialize();
    
    // Mock purchase for web environment
    if (!this.isCapacitorEnvironment) {
      console.log('Mock purchase completed for:', packageToPurchase.identifier);
      return this.getMockCustomerInfo();
    }
    
    try {
      const { customerInfo } = await Purchases.purchasePackage({ aPackage: packageToPurchase });
      return customerInfo;
    } catch (error) {
      console.error('Purchase failed:', error);
      throw error;
    }
  }

  async getCustomerInfo(): Promise<CustomerInfo | null> {
    await this.initialize();
    
    // Return mock customer info for web environment
    if (!this.isCapacitorEnvironment) {
      return this.getMockCustomerInfo();
    }
    
    try {
      const customerInfo = await Purchases.getCustomerInfo();
      return customerInfo;
    } catch (error) {
      console.error('Failed to get customer info:', error);
      return null;
    }
  }

  private getMockCustomerInfo(): CustomerInfo {
    return {
      originalAppUserId: 'demo_user',
      allPurchaseDates: {},
      allExpirationDates: {},
      entitlements: {
        all: {},
        active: {}
      },
      activeSubscriptions: [],
      allPurchasedProductIdentifiers: [],
      nonSubscriptionTransactions: [],
      firstSeen: new Date().toISOString(),
      originalApplicationVersion: '1.0.0',
      requestDate: new Date().toISOString(),
      latestExpirationDate: null,
      originalPurchaseDate: null,
      managementURL: null
    } as CustomerInfo;
  }

  async restorePurchases() {
    await this.initialize();
    
    // Mock restore for web environment
    if (!this.isCapacitorEnvironment) {
      console.log('Mock restore purchases completed');
      return this.getMockCustomerInfo();
    }
    
    try {
      const { customerInfo } = await Purchases.restorePurchases();
      return customerInfo;
    } catch (error) {
      console.error('Failed to restore purchases:', error);
      throw error;
    }
  }

  async setUserId(userId: string) {
    await this.initialize();
    
    // Mock user ID setting for web environment
    if (!this.isCapacitorEnvironment) {
      console.log('Mock user ID set:', userId);
      return;
    }
    
    try {
      await Purchases.logIn({ appUserID: userId });
    } catch (error) {
      console.error('Failed to set user ID:', error);
      throw error;
    }
  }
}

export const revenueCatService = new RevenueCatService();