interface TavusVideoConfig {
  persona_id: string;
  replica_id?: string;
  conversation_config?: {
    callback_url?: string;
    properties?: Record<string, any>;
  };
}

class TavusService {
  private apiKey: string;
  private baseUrl = 'https://tavusapi.com';

  constructor() {
    this.apiKey = import.meta.env.VITE_TAVUS_API_KEY || '';
  }

  async createConversation(config: TavusVideoConfig) {
    if (!this.apiKey) {
      console.warn('Tavus API key not configured, using demo mode');
      return this.getMockConversation();
    }

    try {
      const response = await fetch(`${this.baseUrl}/v2/conversations`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': this.apiKey
        },
        body: JSON.stringify(config)
      });

      if (!response.ok) {
        console.warn(`Tavus API error: ${response.status} ${response.statusText}, falling back to demo mode`);
        return this.getMockConversation();
      }

      return response.json();
    } catch (error) {
      console.warn('Tavus API request failed, using demo mode:', error);
      return this.getMockConversation();
    }
  }

  async getConversation(conversationId: string) {
    if (!this.apiKey) {
      console.warn('Tavus API key not configured, using demo mode');
      return this.getMockConversation();
    }

    try {
      const response = await fetch(`${this.baseUrl}/v2/conversations/${conversationId}`, {
        headers: {
          'x-api-key': this.apiKey
        }
      });

      if (!response.ok) {
        console.warn(`Tavus API error: ${response.status} ${response.statusText}, falling back to demo mode`);
        return this.getMockConversation();
      }

      return response.json();
    } catch (error) {
      console.warn('Tavus API request failed, using demo mode:', error);
      return this.getMockConversation();
    }
  }

  async listPersonas() {
    if (!this.apiKey) {
      console.warn('Tavus API key not configured, using demo mode');
      return this.getMockPersonas();
    }

    try {
      const response = await fetch(`${this.baseUrl}/v2/personas`, {
        headers: {
          'x-api-key': this.apiKey
        }
      });

      if (!response.ok) {
        console.warn(`Tavus API error: ${response.status} ${response.statusText}, falling back to demo mode`);
        return this.getMockPersonas();
      }

      return response.json();
    } catch (error) {
      console.warn('Tavus API request failed, using demo mode:', error);
      return this.getMockPersonas();
    }
  }

  private getMockConversation() {
    return {
      conversation_id: 'demo_conversation_' + Date.now(),
      status: 'active',
      persona_id: 'demo_persona_id',
      created_at: new Date().toISOString(),
      properties: {
        campaign_context: 'cruelty_free_skincare',
        user_role: 'marketing_manager'
      }
    };
  }

  private getMockPersonas() {
    return {
      personas: [
        {
          persona_id: 'demo_persona_id',
          name: 'Campaign Advisor',
          description: 'AI-powered marketing campaign advisor',
          created_at: new Date().toISOString()
        }
      ]
    };
  }
}

export const tavusService = new TavusService();