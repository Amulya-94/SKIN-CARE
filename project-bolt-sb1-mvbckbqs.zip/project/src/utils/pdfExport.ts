import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

export const exportToPDF = async () => {
  try {
    // Show loading state
    const loadingToast = document.createElement('div');
    loadingToast.className = 'fixed top-4 right-4 bg-emerald-600 text-white px-4 py-2 rounded-lg shadow-lg z-50';
    loadingToast.textContent = 'Generating PDF...';
    document.body.appendChild(loadingToast);

    // Get the main content element
    const element = document.querySelector('main') as HTMLElement;
    if (!element) {
      throw new Error('Content not found');
    }

    // Create PDF
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    
    // Add title page
    pdf.setFontSize(24);
    pdf.setTextColor(16, 185, 129); // emerald-500
    pdf.text('CampaignCraft Pro', pageWidth / 2, 40, { align: 'center' });
    
    pdf.setFontSize(18);
    pdf.setTextColor(71, 85, 105); // slate-600
    pdf.text('Cruelty-Free Skincare Campaign Brief', pageWidth / 2, 55, { align: 'center' });
    
    pdf.setFontSize(12);
    pdf.setTextColor(100, 116, 139); // slate-500
    pdf.text('Comprehensive Influencer Marketing Strategy', pageWidth / 2, 70, { align: 'center' });
    pdf.text(`Generated on ${new Date().toLocaleDateString()}`, pageWidth / 2, 80, { align: 'center' });

    // Add brand elements
    pdf.setDrawColor(16, 185, 129);
    pdf.setLineWidth(0.5);
    pdf.line(20, 90, pageWidth - 20, 90);

    // Add sections content
    const sections = [
      'Campaign Objectives',
      'Target Audience', 
      'Key Brand Messages',
      'Content Themes & Formats',
      'Social Media Platforms',
      'Influencer Selection Criteria',
      'Campaign Timeline',
      'Success Metrics & KPIs'
    ];

    let yPosition = 110;
    
    sections.forEach((sectionTitle, index) => {
      if (yPosition > pageHeight - 40) {
        pdf.addPage();
        yPosition = 20;
      }
      
      pdf.setFontSize(16);
      pdf.setTextColor(71, 85, 105);
      pdf.text(`${index + 1}. ${sectionTitle}`, 20, yPosition);
      yPosition += 15;
      
      // Add section content based on the section
      pdf.setFontSize(10);
      pdf.setTextColor(100, 116, 139);
      
      const sectionContent = getSectionContent(sectionTitle);
      const lines = pdf.splitTextToSize(sectionContent, pageWidth - 40);
      
      lines.forEach((line: string) => {
        if (yPosition > pageHeight - 20) {
          pdf.addPage();
          yPosition = 20;
        }
        pdf.text(line, 20, yPosition);
        yPosition += 5;
      });
      
      yPosition += 10;
    });

    // Add footer to all pages
    const totalPages = pdf.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      pdf.setPage(i);
      pdf.setFontSize(8);
      pdf.setTextColor(148, 163, 184);
      pdf.text('CampaignCraft Pro - Professional Influencer Marketing Platform', pageWidth / 2, pageHeight - 10, { align: 'center' });
      pdf.text(`Page ${i} of ${totalPages}`, pageWidth - 20, pageHeight - 10, { align: 'right' });
    }

    // Save the PDF
    pdf.save('CampaignCraft-Pro-Campaign-Brief.pdf');

    // Remove loading toast
    document.body.removeChild(loadingToast);

    // Show success message
    const successToast = document.createElement('div');
    successToast.className = 'fixed top-4 right-4 bg-green-600 text-white px-4 py-2 rounded-lg shadow-lg z-50';
    successToast.textContent = 'PDF exported successfully!';
    document.body.appendChild(successToast);
    
    setTimeout(() => {
      document.body.removeChild(successToast);
    }, 3000);

  } catch (error) {
    console.error('Error generating PDF:', error);
    
    // Show error message
    const errorToast = document.createElement('div');
    errorToast.className = 'fixed top-4 right-4 bg-red-600 text-white px-4 py-2 rounded-lg shadow-lg z-50';
    errorToast.textContent = 'Error generating PDF. Please try again.';
    document.body.appendChild(errorToast);
    
    setTimeout(() => {
      document.body.removeChild(errorToast);
    }, 3000);
  }
};

const getSectionContent = (sectionTitle: string): string => {
  const content: { [key: string]: string } = {
    'Campaign Objectives': 'Increase cruelty-free brand awareness by 35% within 6 months through authentic storytelling and ethical positioning. Generate buzz around new product launches with emphasis on ingredient transparency. Build an engaged community of ethically-minded consumers. Drive 25% increase in online sales through authentic product demonstrations. Raise awareness about cruelty-free practices and empower consumers to make ethical beauty choices.',
    
    'Target Audience': 'Demographics: Age 22-45 years, 75% Female 25% Male, Urban & Suburban locations, Income $40K-$100K+, College-educated. Psychographics: Values animal welfare, environmental sustainability, ethical consumption, transparency. Interests in clean beauty, wellness, sustainable living. Research-driven, value-conscious, socially aware consumers.',
    
    'Key Brand Messages': 'Cruelty-Free Commitment: Beauty without compromise - products never tested on animals, certified cruelty-free. Transparency & Trust: Complete ingredient transparency, honest communication, authentic brand values. Ethical Sourcing: Responsibly sourced ingredients respecting people and planet. Authentic Results: Real results from real ingredients - effective skincare aligned with values.',
    
    'Content Themes & Formats': 'Educational Content: Ingredient spotlights, skincare education, ethics & values content. Authentic Reviews: Honest product reviews, before & after transformations, comparison content. Lifestyle Integration: Daily routines, behind-the-scenes content, user-generated content showcasing real experiences.',
    
    'Social Media Platforms': 'Instagram (Primary): Visual storytelling through posts, stories, and reels. Focus on product photography, tutorials, behind-the-scenes content. Target audience 25-40 years. TikTok (Primary): Short-form educational content, trending challenges, authentic demonstrations. YouTube (Secondary): Long-form educational content, detailed reviews, comprehensive guides.',
    
    'Influencer Selection Criteria': 'Quantitative: 10K-500K followers, ≥3.5% engagement rate, high content quality standards. Qualitative: Values alignment with cruelty-free practices, authentic voice with transparent communication, audience demographics matching target market, professional standards with reliable delivery.',
    
    'Campaign Timeline': 'Phase 1 (Weeks 1-2): Pre-Launch - Influencer outreach, contract negotiations, content brief creation, product sampling. Phase 2 (Weeks 3-8): Active Campaign - Content creation, scheduled publication, engagement monitoring, community management. Phase 3 (Weeks 9-10): Post-Campaign - Performance analysis, feedback collection, relationship nurturing.',
    
    'Success Metrics & KPIs': 'Awareness Metrics: 2M+ total reach, 8M+ impressions, +150% brand mentions. Engagement Metrics: ≥4.5% engagement rate, high-quality comments, ≥2% share rate. Conversion Metrics: ≥2.5% click-through rate, ≥3% conversion rate, 25%+ revenue attribution. Qualitative indicators include positive sentiment, increased brand trust, and strengthened influencer relationships.'
  };
  
  return content[sectionTitle] || 'Content details for this section...';
};