/*
  # Create comprehensive database schema for CampaignCraft Pro

  1. New Tables
    - `profiles` - User profile information
    - `campaign_briefs` - Campaign brief storage with full data
    - `campaign_analytics` - Real-time analytics tracking
    - `influencer_partnerships` - Partnership management
    - `content_calendar` - Content scheduling and tracking
    - `campaign_collaborators` - Team collaboration features

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Secure data access patterns

  3. Functions
    - Campaign analytics calculations
    - Viral prediction scoring
    - Ethical impact tracking
*/

-- Create profiles table for user management
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  full_name text,
  company text,
  role text DEFAULT 'marketing_manager',
  subscription_tier text DEFAULT 'free',
  avatar_url text,
  preferences jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create campaign briefs table
CREATE TABLE IF NOT EXISTS campaign_briefs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  brand_name text NOT NULL,
  campaign_type text DEFAULT 'influencer_marketing',
  status text DEFAULT 'draft',
  objectives jsonb DEFAULT '{}',
  target_audience jsonb DEFAULT '{}',
  key_messages jsonb DEFAULT '{}',
  content_themes jsonb DEFAULT '{}',
  platforms jsonb DEFAULT '{}',
  selection_criteria jsonb DEFAULT '{}',
  timeline jsonb DEFAULT '{}',
  budget_range text,
  success_metrics jsonb DEFAULT '{}',
  viral_score integer DEFAULT 0,
  ethical_score integer DEFAULT 0,
  is_public boolean DEFAULT false,
  tags text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create campaign analytics table
CREATE TABLE IF NOT EXISTS campaign_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid REFERENCES campaign_briefs(id) ON DELETE CASCADE,
  metric_type text NOT NULL,
  metric_value numeric NOT NULL,
  metric_date date DEFAULT CURRENT_DATE,
  platform text,
  influencer_id text,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Create influencer partnerships table
CREATE TABLE IF NOT EXISTS influencer_partnerships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid REFERENCES campaign_briefs(id) ON DELETE CASCADE,
  influencer_name text NOT NULL,
  platform text NOT NULL,
  follower_count integer,
  engagement_rate numeric,
  partnership_status text DEFAULT 'prospecting',
  contact_email text,
  rate_per_post numeric,
  content_delivered integer DEFAULT 0,
  performance_metrics jsonb DEFAULT '{}',
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create content calendar table
CREATE TABLE IF NOT EXISTS content_calendar (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid REFERENCES campaign_briefs(id) ON DELETE CASCADE,
  influencer_id uuid REFERENCES influencer_partnerships(id),
  content_type text NOT NULL,
  platform text NOT NULL,
  scheduled_date timestamptz,
  status text DEFAULT 'planned',
  content_brief text,
  approval_status text DEFAULT 'pending',
  performance_data jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create campaign collaborators table
CREATE TABLE IF NOT EXISTS campaign_collaborators (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid REFERENCES campaign_briefs(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  role text DEFAULT 'viewer',
  permissions jsonb DEFAULT '{}',
  invited_by uuid REFERENCES auth.users(id),
  invited_at timestamptz DEFAULT now(),
  accepted_at timestamptz
);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaign_briefs ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaign_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE influencer_partnerships ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_calendar ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaign_collaborators ENABLE ROW LEVEL SECURITY;

-- Create policies for profiles
CREATE POLICY "Users can read own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own profile"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create policies for campaign briefs
CREATE POLICY "Users can read own campaigns"
  ON campaign_briefs
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id OR is_public = true);

CREATE POLICY "Users can create campaigns"
  ON campaign_briefs
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own campaigns"
  ON campaign_briefs
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own campaigns"
  ON campaign_briefs
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create policies for campaign analytics
CREATE POLICY "Users can read analytics for their campaigns"
  ON campaign_analytics
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM campaign_briefs 
      WHERE id = campaign_analytics.campaign_id 
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert analytics for their campaigns"
  ON campaign_analytics
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM campaign_briefs 
      WHERE id = campaign_analytics.campaign_id 
      AND user_id = auth.uid()
    )
  );

-- Create policies for influencer partnerships
CREATE POLICY "Users can manage partnerships for their campaigns"
  ON influencer_partnerships
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM campaign_briefs 
      WHERE id = influencer_partnerships.campaign_id 
      AND user_id = auth.uid()
    )
  );

-- Create policies for content calendar
CREATE POLICY "Users can manage content for their campaigns"
  ON content_calendar
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM campaign_briefs 
      WHERE id = content_calendar.campaign_id 
      AND user_id = auth.uid()
    )
  );

-- Create policies for collaborators
CREATE POLICY "Users can view collaborations they're part of"
  ON campaign_collaborators
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() = user_id OR 
    EXISTS (
      SELECT 1 FROM campaign_briefs 
      WHERE id = campaign_collaborators.campaign_id 
      AND user_id = auth.uid()
    )
  );

-- Create functions for analytics calculations
CREATE OR REPLACE FUNCTION calculate_viral_score(campaign_id uuid)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  score integer := 0;
  engagement_avg numeric;
  reach_total numeric;
  share_rate numeric;
BEGIN
  -- Calculate engagement average
  SELECT AVG(metric_value) INTO engagement_avg
  FROM campaign_analytics
  WHERE campaign_analytics.campaign_id = calculate_viral_score.campaign_id
  AND metric_type = 'engagement_rate';
  
  -- Calculate total reach
  SELECT SUM(metric_value) INTO reach_total
  FROM campaign_analytics
  WHERE campaign_analytics.campaign_id = calculate_viral_score.campaign_id
  AND metric_type = 'reach';
  
  -- Calculate share rate
  SELECT AVG(metric_value) INTO share_rate
  FROM campaign_analytics
  WHERE campaign_analytics.campaign_id = calculate_viral_score.campaign_id
  AND metric_type = 'share_rate';
  
  -- Calculate viral score based on metrics
  score := COALESCE(engagement_avg * 10, 0) + 
           COALESCE(LEAST(reach_total / 10000, 50), 0) + 
           COALESCE(share_rate * 20, 0);
  
  RETURN LEAST(score, 100);
END;
$$;

-- Create function for ethical impact calculation
CREATE OR REPLACE FUNCTION calculate_ethical_score(campaign_id uuid)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  score integer := 0;
  campaign_data jsonb;
BEGIN
  -- Get campaign data
  SELECT 
    objectives || target_audience || key_messages 
  INTO campaign_data
  FROM campaign_briefs
  WHERE id = calculate_ethical_score.campaign_id;
  
  -- Score based on ethical keywords and practices
  IF campaign_data::text ILIKE '%cruelty-free%' THEN
    score := score + 25;
  END IF;
  
  IF campaign_data::text ILIKE '%sustainable%' OR campaign_data::text ILIKE '%ethical%' THEN
    score := score + 20;
  END IF;
  
  IF campaign_data::text ILIKE '%transparency%' THEN
    score := score + 15;
  END IF;
  
  IF campaign_data::text ILIKE '%authentic%' THEN
    score := score + 15;
  END IF;
  
  -- Base score for any campaign
  score := score + 25;
  
  RETURN LEAST(score, 100);
END;
$$;

-- Create trigger to update timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_campaign_briefs_updated_at BEFORE UPDATE ON campaign_briefs
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_influencer_partnerships_updated_at BEFORE UPDATE ON influencer_partnerships
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_content_calendar_updated_at BEFORE UPDATE ON content_calendar
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert sample data for demonstration
INSERT INTO profiles (user_id, email, full_name, company, role, subscription_tier) VALUES
  ('00000000-0000-0000-0000-000000000000', 'demo@campaigncraft.pro', 'Demo User', 'CampaignCraft Pro', 'marketing_manager', 'pro');

INSERT INTO campaign_briefs (
  user_id, 
  title, 
  brand_name, 
  campaign_type,
  status,
  objectives,
  target_audience,
  viral_score,
  ethical_score,
  is_public
) VALUES (
  '00000000-0000-0000-0000-000000000000',
  'Cruelty-Free Skincare Campaign',
  'EthiBeauty',
  'influencer_marketing',
  'active',
  '{"brand_awareness": 35, "sales_increase": 25, "community_building": true}',
  '{"age_range": "22-45", "gender": "75% female", "values": ["cruelty-free", "ethical", "sustainable"]}',
  87,
  94,
  true
);