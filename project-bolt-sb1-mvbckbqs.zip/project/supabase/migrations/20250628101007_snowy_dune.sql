/*
  # Fix Profile Email Issue

  1. Update existing profiles to ensure email is populated
  2. Add trigger to automatically populate email from auth.users
  3. Ensure data consistency
*/

-- Update existing profiles that have empty email but valid user_id
UPDATE profiles 
SET email = auth.users.email
FROM auth.users 
WHERE profiles.user_id = auth.users.id 
AND (profiles.email IS NULL OR profiles.email = '');

-- Create function to automatically set email from auth.users
CREATE OR REPLACE FUNCTION set_profile_email()
RETURNS TRIGGER AS $$
BEGIN
  -- If email is not provided, get it from auth.users
  IF NEW.email IS NULL OR NEW.email = '' THEN
    SELECT email INTO NEW.email 
    FROM auth.users 
    WHERE id = NEW.user_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to automatically set email on insert/update
DROP TRIGGER IF EXISTS set_profile_email_trigger ON profiles;
CREATE TRIGGER set_profile_email_trigger
  BEFORE INSERT OR UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION set_profile_email();

-- Ensure email is always populated for existing records
DO $$
DECLARE
  profile_record RECORD;
  user_email TEXT;
BEGIN
  FOR profile_record IN 
    SELECT p.id, p.user_id, p.email, u.email as auth_email
    FROM profiles p
    JOIN auth.users u ON p.user_id = u.id
    WHERE p.email IS NULL OR p.email = '' OR p.email != u.email
  LOOP
    UPDATE profiles 
    SET email = profile_record.auth_email,
        updated_at = now()
    WHERE id = profile_record.id;
  END LOOP;
END $$;